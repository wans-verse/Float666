package com.wans.platscan

import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import org.json.JSONArray
import org.json.JSONObject

/** Daftar pilihan jenis, tipe (per jenis) dan warna; disimpan di SharedPreferences. */
object Options {
    private const val PREF = "opts"
    private const val KEY = "data"

    private val defJenis = listOf("Motor", "Mobil")
    private val defTipe = mapOf(
        "Motor" to listOf(
            "Vario", "Beat", "Scoopy", "PCX", "Genio", "CB150R", "CBR150R", "Supra X", "Revo",
            "NMAX", "Aerox", "Mio", "Vixion", "R15", "Jupiter", "Satria FU", "Ninja", "Vespa"
        ),
        "Mobil" to listOf(
            "Avanza", "Xenia", "Brio", "Jazz", "Agya", "Ayla", "Calya", "Sigra", "Ertiga",
            "Innova", "Fortuner", "Pajero", "Rush", "Terios", "Mobilio", "Xpander", "HR-V", "CR-V"
        )
    )
    private val defWarna = listOf(
        "Hitam", "Putih", "Merah", "Biru", "Silver", "Abu-abu", "Hijau", "Kuning", "Coklat", "Orange"
    )

    fun snapshot(c: Context): JSONObject = load(c)

    /** Gabungkan daftar pilihan dari backup (yang sudah ada tidak dihapus). */
    fun merge(c: Context, o: JSONObject) {
        o.optJSONArray("jenis")?.strings()?.forEach { addJenis(c, it) }
        o.optJSONArray("warna")?.strings()?.forEach { addWarna(c, it) }
        o.optJSONObject("tipe")?.let { t ->
            t.keys().forEach { j -> t.getJSONArray(j).strings().forEach { addTipe(c, j, it) } }
        }
    }

    private fun load(c: Context): JSONObject {
        val s = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null)
        if (s != null) try { return JSONObject(s) } catch (_: Exception) {}
        return JSONObject().apply {
            put("jenis", JSONArray(defJenis))
            put("warna", JSONArray(defWarna))
            put("tipe", JSONObject().also { o -> defTipe.forEach { (k, v) -> o.put(k, JSONArray(v)) } })
        }
    }

    private fun save(c: Context, o: JSONObject) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    private fun JSONArray.strings(): MutableList<String> =
        MutableList(length()) { getString(it) }

    private fun tipeKey(o: JSONObject, jenis: String): String? =
        o.getJSONObject("tipe").keys().asSequence().firstOrNull { it.equals(jenis, true) }

    fun jenis(c: Context) = load(c).getJSONArray("jenis").strings().sortedBy { it.lowercase() }
    fun warna(c: Context) = load(c).getJSONArray("warna").strings().sortedBy { it.lowercase() }
    fun tipe(c: Context, jenis: String): List<String> {
        val o = load(c)
        val k = tipeKey(o, jenis) ?: return emptyList()
        return o.getJSONObject("tipe").getJSONArray(k).strings().sortedBy { it.lowercase() }
    }

    private fun addTo(list: MutableList<String>, v: String): Boolean {
        val s = v.trim()
        if (s.isEmpty() || list.any { it.equals(s, true) }) return false
        list.add(s); return true
    }

    fun addJenis(c: Context, v: String) {
        val o = load(c); val l = o.getJSONArray("jenis").strings()
        if (addTo(l, v)) { o.put("jenis", JSONArray(l)); save(c, o) }
    }

    fun removeJenis(c: Context, v: String) {
        val o = load(c)
        o.put("jenis", JSONArray(o.getJSONArray("jenis").strings().filterNot { it == v }))
        tipeKey(o, v)?.let { o.getJSONObject("tipe").remove(it) }
        save(c, o)
    }

    fun addTipe(c: Context, jenis: String, v: String) {
        if (jenis.isBlank()) return
        addJenis(c, jenis)
        val o = load(c)
        val k = tipeKey(o, jenis) ?: jenis.trim()
        val t = o.getJSONObject("tipe")
        val l = if (t.has(k)) t.getJSONArray(k).strings() else mutableListOf()
        if (addTo(l, v)) { t.put(k, JSONArray(l)); save(c, o) }
    }

    fun removeTipe(c: Context, jenis: String, v: String) {
        val o = load(c); val k = tipeKey(o, jenis) ?: return
        val t = o.getJSONObject("tipe")
        t.put(k, JSONArray(t.getJSONArray(k).strings().filterNot { it == v }))
        save(c, o)
    }

    fun addWarna(c: Context, v: String) {
        val o = load(c); val l = o.getJSONArray("warna").strings()
        if (addTo(l, v)) { o.put("warna", JSONArray(l)); save(c, o) }
    }

    fun removeWarna(c: Context, v: String) {
        val o = load(c)
        o.put("warna", JSONArray(o.getJSONArray("warna").strings().filterNot { it == v }))
        save(c, o)
    }

    /** Warna titik di chip, ditebak dari nama warna. */
    fun colorFor(name: String): Int {
        val n = name.lowercase()
        val map = listOf(
            "hitam" to 0xFF1A1A1A, "putih" to 0xFFFFFFFF, "merah" to 0xFFE53935, "biru" to 0xFF1E64F0,
            "silver" to 0xFFC0C0C0, "abu" to 0xFF8A8A8A, "hijau" to 0xFF2E9E4F, "kuning" to 0xFFFFD600,
            "coklat" to 0xFF795548, "cokelat" to 0xFF795548, "orange" to 0xFFFB8C00, "oranye" to 0xFFFB8C00,
            "ungu" to 0xFF8E24AA, "pink" to 0xFFF48FB1, "emas" to 0xFFD4AF37, "gold" to 0xFFD4AF37,
            "maroon" to 0xFF800000, "marun" to 0xFF800000, "krem" to 0xFFF5E6C8, "cream" to 0xFFF5E6C8
        )
        return (map.firstOrNull { n.contains(it.first) }?.second ?: 0xFF9FB4FF).toInt()
    }

    fun dot(color: Int, c: Context): Drawable {
        val d = c.resources.displayMetrics.density
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke((1.5f * d).toInt(), 0x99FFFFFF.toInt())
            setSize((18 * d).toInt(), (18 * d).toInt())
        }
    }

    /** Masukkan nilai dari data/impor CSV ke daftar pilihan. */
    fun learn(c: Context, list: List<Vehicle>) {
        for (v in list) {
            if (v.jenis.isNotBlank()) addJenis(c, v.jenis)
            if (v.jenis.isNotBlank() && v.tipe.isNotBlank()) addTipe(c, v.jenis, v.tipe)
            if (v.warna.isNotBlank()) addWarna(c, v.warna)
        }
    }
}

/**
 * Sheet pilihan berbentuk chip dengan pencarian. [items] dipanggil ulang tiap daftar berubah.
 * Mode pilih: [onPick] diisi. Mode kelola: [onRemove] diisi (tombol x di tiap chip).
 */
fun Context.showOptionSheet(
    title: String,
    items: () -> List<String>,
    current: String = "",
    onAdd: ((String) -> Unit)? = null,
    onPick: ((String) -> Unit)? = null,
    onClear: (() -> Unit)? = null,
    onRemove: ((String) -> Unit)? = null,
    onChanged: (() -> Unit)? = null,
    swatch: Boolean = false
) {
    val sheet = BottomSheetDialog(this)
    val view = LayoutInflater.from(this).inflate(R.layout.sheet_option, null)
    val et = view.findViewById<TextView>(R.id.etOpt)
    val btnAdd = view.findViewById<MaterialButton>(R.id.btnOptAdd)
    val btnClear = view.findViewById<MaterialButton>(R.id.btnOptClear)
    val empty = view.findViewById<TextView>(R.id.tvOptEmpty)
    val group = view.findViewById<ChipGroup>(R.id.groupOpt)
    view.findViewById<TextView>(R.id.tvOptTitle).text = title

    fun refresh() {
        val q = et.text.toString().trim()
        val all = items()
        val res = all.filter { q.isEmpty() || it.contains(q, true) }
        group.removeAllViews()
        for (s in res) {
            val chip = Chip(this)
            chip.text = s
            chip.chipIconTint = null
            if (swatch) {
                chip.chipIcon = Options.dot(Options.colorFor(s), this)
                chip.isChipIconVisible = true
            }
            if (onRemove != null) {
                chip.isCloseIconVisible = true
                chip.setOnCloseIconClickListener {
                    onRemove(s); refresh(); onChanged?.invoke()
                }
            } else {
                chip.isCheckable = true
                chip.isChecked = s.equals(current, true)
                chip.setOnClickListener { sheet.dismiss(); onPick?.invoke(s) }
            }
            group.addView(chip)
        }
        empty.visibility = if (res.isEmpty()) View.VISIBLE else View.GONE
        val exists = all.any { it.equals(q, true) }
        btnAdd.visibility = if (onAdd != null && q.isNotEmpty() && !exists) View.VISIBLE else View.GONE
        btnAdd.text = "Tambah \"$q\""
    }
    et.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { refresh() }
    })
    btnAdd.setOnClickListener {
        val v = et.text.toString().trim()
        onAdd?.invoke(v)
        onChanged?.invoke()
        if (onPick != null) { sheet.dismiss(); onPick(v) }
        else { et.text = ""; refresh() }
    }
    btnClear.visibility = if (onClear != null && current.isNotBlank()) View.VISIBLE else View.GONE
    btnClear.setOnClickListener { sheet.dismiss(); onClear?.invoke() }
    refresh()
    sheet.setContentView(view)
    sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
    sheet.show()
}
