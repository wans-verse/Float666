package com.wans.platscan

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

private fun TextView.setOrHide(s: String) {
    text = s
    visibility = if (s.isBlank()) View.GONE else View.VISIBLE
}

class VehicleAdapter(private val onClick: (Vehicle) -> Unit) :
    ListAdapter<Vehicle, VehicleAdapter.VH>(object : DiffUtil.ItemCallback<Vehicle>() {
        override fun areItemsTheSame(a: Vehicle, b: Vehicle) = a.plateKey == b.plateKey
        override fun areContentsTheSame(a: Vehicle, b: Vehicle) = a == b
    }) {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val plate: TextView = v.findViewById(R.id.tvPlate)
        val name: TextView = v.findViewById(R.id.tvName)
        val detail: TextView = v.findViewById(R.id.tvDetail)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_vehicle, parent, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val v = getItem(i)
        h.plate.text = v.plate
        h.name.setOrHide(v.nama)
        h.detail.setOrHide(v.detail())
        h.itemView.setOnClickListener { onClick(v) }
    }
}

class TargetAdapter(private val onClick: (Target) -> Unit) :
    ListAdapter<Target, TargetAdapter.VH>(object : DiffUtil.ItemCallback<Target>() {
        override fun areItemsTheSame(a: Target, b: Target) = a.plateKey == b.plateKey
        override fun areContentsTheSame(a: Target, b: Target) = a == b
    }) {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val plate: TextView = v.findViewById(R.id.tvPlate)
        val note: TextView = v.findViewById(R.id.tvName)
        val unused: TextView = v.findViewById(R.id.tvDetail)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_vehicle, parent, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val t = getItem(i)
        h.plate.text = t.plate
        h.note.setOrHide(t.nama.ifBlank { t.note })
        val kend = listOf(t.jenis, t.tipe, t.warna).filter { it.isNotBlank() }.joinToString(" \u00B7 ")
        val extra = if (t.nama.isBlank()) "" else t.note
        h.unused.setOrHide(listOf(kend, extra).filter { it.isNotBlank() }.joinToString("\n"))
        h.itemView.setOnClickListener { onClick(t) }
    }
}

class LogAdapter(
    private val onMap: (ScanLog) -> Unit,
    private val onShare: (ScanLog) -> Unit,
    private val onPhoto: (ScanLog) -> Unit
) : ListAdapter<LogRow, LogAdapter.VH>(object : DiffUtil.ItemCallback<LogRow>() {
        override fun areItemsTheSame(a: LogRow, b: LogRow) = a.log.id == b.log.id
        override fun areContentsTheSame(a: LogRow, b: LogRow) = a == b
    }) {

    class VH(v: View, val header: TextView) : RecyclerView.ViewHolder(v) {
        val plate: TextView = v.findViewById(R.id.tvPlate)
        val tag: TextView = v.findViewById(R.id.tvTag)
        val name: TextView = v.findViewById(R.id.tvName)
        val time: TextView = v.findViewById(R.id.tvTime)
        val coords: TextView = v.findViewById(R.id.tvCoords)
        val address: TextView = v.findViewById(R.id.tvAddress)
        val photo: ImageView = v.findViewById(R.id.ivPhoto)
        val actions: View = v.findViewById(R.id.actions)
        val btnMap: MaterialButton = v.findViewById(R.id.btnMap)
        val btnShare: MaterialButton = v.findViewById(R.id.btnShare)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val wrap = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(-1, -2)
        }
        val header = TextView(parent.context).apply {
            textSize = 16f
            setTextColor(0xFFFFC933.toInt())
            setPadding(4, 16, 4, 16)
        }
        wrap.addView(header)
        wrap.addView(LayoutInflater.from(parent.context).inflate(R.layout.item_log, wrap, false))
        return VH(wrap, header)
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val row = getItem(i)
        val l = row.log
        h.header.setOrHide(row.header.orEmpty())
        h.plate.text = l.plate
        h.tag.text = if (l.isTarget) "TARGET" else "TIDAK TERDAFTAR"
        h.tag.visibility = if (l.isTarget || l.unregistered()) View.VISIBLE else View.GONE
        val asal = Wilayah.of(l.plate)
        h.time.text = Fmt.time(l.scannedAt) + if (asal == null) "" else "\nAsal: $asal"
        if (row.count > 1) h.time.append("\nTerlihat ${row.count} kali, terakhir pada jam di atas")

        if (!l.isTarget) {
            h.name.setOrHide(l.nama)
            h.coords.visibility = View.GONE
            h.address.visibility = View.GONE
            h.actions.visibility = View.GONE
            h.photo.visibility = View.GONE
            h.photo.tag = null
            return
        }

        h.name.setOrHide(l.displayName().ifBlank { l.catatan })

        val lat = l.lat
        val lon = l.lon
        val hasLoc = lat != null && lon != null
        h.coords.visibility = View.VISIBLE
        if (lat != null && lon != null) {
            val sb = StringBuilder(Fmt.coords(lat, lon))
            val acc = Fmt.accuracy(l.accuracy)
            if (acc.isNotEmpty()) sb.append(" \u00B7 ").append(acc)
            if (l.approx) sb.append(" \u00B7 perkiraan")
            h.coords.text = sb.toString()
        } else {
            h.coords.text = "Lokasi tidak tersedia"
        }
        h.address.setOrHide(l.address.orEmpty())

        h.actions.visibility = View.VISIBLE
        h.btnMap.visibility = if (hasLoc) View.VISIBLE else View.GONE
        h.btnMap.setOnClickListener { onMap(l) }
        h.btnShare.setOnClickListener { onShare(l) }

        val p = l.photo
        if (p == null) {
            h.photo.visibility = View.GONE
            h.photo.tag = null
        } else {
            h.photo.visibility = View.VISIBLE
            h.photo.setImageDrawable(null)
            h.photo.tag = p
            h.photo.setOnClickListener { onPhoto(l) }
            Evidence.thumb(h.itemView.context, p) { bmp ->
                if (bmp != null && h.photo.tag == p) h.photo.setImageBitmap(bmp)
            }
        }
    }
}
