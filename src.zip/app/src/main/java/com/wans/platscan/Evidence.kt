package com.wans.platscan

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Foto bukti: satu frame kamera, disimpan di penyimpanan internal aplikasi. */
object Evidence {

    /** Salinan ringan frame (NV21) yang aman dipakai setelah ImageProxy ditutup. */
    class Snapshot(val nv21: ByteArray, val w: Int, val h: Int, val rotation: Int)

    private val main = Handler(Looper.getMainLooper())
    private val loader = Executors.newFixedThreadPool(2)
    private val cache = object : LruCache<String, Bitmap>(10 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun dir(c: Context): File = File(c.filesDir, "evidence").also { it.mkdirs() }
    fun file(c: Context, name: String): File = File(dir(c), name)

    /** Cepat (hanya menyalin byte); aman dipanggil di main thread selama image masih terbuka. */
    fun snapshot(img: Image, rotation: Int): Snapshot? {
        return try {
            if (img.format != ImageFormat.YUV_420_888 || img.planes.size < 3) return null
            val w = img.width
            val h = img.height
            val yp = img.planes[0]
            val up = img.planes[1]
            val vp = img.planes[2]
            val out = ByteArray(w * h * 3 / 2)
            val yb = yp.buffer.duplicate()
            var pos = 0
            for (row in 0 until h) {
                yb.position(row * yp.rowStride)
                yb.get(out, pos, w)
                pos += w
            }
            val ub = up.buffer.duplicate()
            val vb = vp.buffer.duplicate()
            for (row in 0 until h / 2) {
                for (col in 0 until w / 2) {
                    out[pos++] = vb.get(row * vp.rowStride + col * vp.pixelStride)
                    out[pos++] = ub.get(row * up.rowStride + col * up.pixelStride)
                }
            }
            Snapshot(out, w, h, rotation)
        } catch (e: Exception) {
            null
        }
    }

    /** Blocking; panggil dari background thread. Mengembalikan nama file, atau null bila gagal. */
    fun save(c: Context, s: Snapshot): String? {
        try {
            val jpeg = ByteArrayOutputStream()
            YuvImage(s.nv21, ImageFormat.NV21, s.w, s.h, null)
                .compressToJpeg(Rect(0, 0, s.w, s.h), 95, jpeg)
            val bytes = jpeg.toByteArray()
            var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            if (s.rotation != 0) {
                val m = Matrix()
                m.postRotate(s.rotation.toFloat())
                val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (r !== bmp) bmp.recycle()
                bmp = r
            }
            val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + ".jpg"
            FileOutputStream(file(c, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            bmp.recycle()
            return name
        } catch (e: Exception) {
            return null
        }
    }

    fun clearAll(c: Context) {
        dir(c).listFiles()?.forEach { it.delete() }
        cache.evictAll()
    }

    /** Decode dengan downsampling; sisi terpendek hasil minimal sekitar [minSide] px. */
    fun decodeSampled(f: File, minSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= minSide && bounds.outHeight / (sample * 2) >= minSide) {
                sample *= 2
            }
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }

    /** Thumbnail asinkron dengan cache. Callback selalu di main thread. */
    fun thumb(c: Context, name: String, cb: (Bitmap?) -> Unit) {
        val app = c.applicationContext
        val hit = cache.get(name)
        if (hit != null) { cb(hit); return }
        loader.execute {
            val f = file(app, name)
            val bmp = if (f.exists()) decodeSampled(f, 200) else null
            if (bmp != null) cache.put(name, bmp)
            main.post { cb(bmp) }
        }
    }
}
