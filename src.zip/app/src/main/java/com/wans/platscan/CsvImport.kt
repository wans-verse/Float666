package com.wans.platscan

object CsvImport {

    fun parse(raw: String): List<List<String>> {
        val text = raw.removePrefix("\uFEFF")
        val firstLine = text.lineSequence().firstOrNull().orEmpty()
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> firstLine.count { it == d } } ?: ','

        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val sb = StringBuilder()
        var inQuote = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (inQuote) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { sb.append('"'); i++ }
                    else inQuote = false
                } else sb.append(c)
            } else {
                when (c) {
                    '"' -> inQuote = true
                    delim -> { row.add(sb.toString()); sb.setLength(0) }
                    '\r' -> {}
                    '\n' -> {
                        row.add(sb.toString()); sb.setLength(0)
                        rows.add(row); row = ArrayList()
                    }
                    else -> sb.append(c)
                }
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) { row.add(sb.toString()); rows.add(row) }
        return rows.filter { r -> r.any { it.isNotBlank() } }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetter() }

    private val plateNames = setOf("noplat", "plat", "nopolisi", "nopol", "platnomor", "nomorplat")
    private val namaNames = setOf("nama", "pemilik")
    private val jenisNames = setOf("jeniskendaraan", "jenis", "kendaraan")
    private val tipeNames = setOf("tipe", "type")
    private val warnaNames = setOf("warna")
    private val ketNames = setOf("keterangan", "ket", "catatan")

    /** Hasil: daftar kendaraan (plat dobel dalam file = satu data) dan jumlah baris yang dilewati. */
    fun toVehicles(rows: List<List<String>>): Pair<List<Vehicle>, Int> {
        if (rows.isEmpty()) return Pair(emptyList(), 0)
        val header = rows[0].map { norm(it) }
        val plateIdx = header.indexOfFirst { it in plateNames }
        val hasHeader = plateIdx >= 0

        fun idx(names: Set<String>, fallback: Int) =
            if (hasHeader) header.indexOfFirst { it in names } else fallback

        val iPlate = if (hasHeader) plateIdx else 0
        val iNama = idx(namaNames, 1)
        val iJenis = idx(jenisNames, 2)
        val iTipe = idx(tipeNames, 3)
        val iWarna = idx(warnaNames, 4)
        val iKet = idx(ketNames, 5)

        val out = LinkedHashMap<String, Vehicle>()
        var skipped = 0
        for (r in if (hasHeader) rows.drop(1) else rows) {
            fun get(i: Int) = if (i < 0) "" else r.getOrNull(i)?.trim().orEmpty()
            val rawPlate = get(iPlate)
            val key = PlateParser.key(rawPlate)
            if (key.isEmpty()) { skipped++; continue }
            out[key] = Vehicle(
                plateKey = key,
                plate = PlateParser.format(rawPlate),
                nama = get(iNama),
                jenis = get(iJenis),
                tipe = get(iTipe),
                warna = get(iWarna),
                keterangan = get(iKet)
            )
        }
        return Pair(out.values.toList(), skipped)
    }
}
