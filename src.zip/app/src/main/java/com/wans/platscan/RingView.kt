package com.wans.platscan

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View

/** Cincin statistik: porsi Data / Target / Riwayat, angka total data di tengah. */
class RingView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private var counts = intArrayOf(0, 0, 0)
    private val colors = intArrayOf(0xFF6CB6FF.toInt(), 0xFFFF6B7D.toInt(), 0xFF5BE08A.toInt())
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x33FFFFFF
    }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt(); textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    fun set(data: Int, target: Int, log: Int) {
        counts = intArrayOf(data, target, log)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val size = minOf(width, height).toFloat()
        if (size <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        val stroke = size * 0.085f
        arc.strokeWidth = stroke
        track.strokeWidth = stroke
        val r = size / 2f - stroke
        rect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(rect, 0f, 360f, false, track)

        val total = counts.sum()
        val used = counts.count { it > 0 }
        if (total > 0) {
            val gap = if (used > 1) 22f else 0f
            val avail = 360f - gap * used
            var start = -90f + gap / 2f
            for (i in 0..2) {
                if (counts[i] <= 0) continue
                val sweep = avail * counts[i] / total
                arc.color = colors[i]
                canvas.drawArc(rect, start, maxOf(sweep, 1f), false, arc)
                start += sweep + gap
            }
        }

        val ir = size * 0.30f
        disc.shader = RadialGradient(
            cx, cy, ir, intArrayOf(0xFF2C3541.toInt(), 0xFF1D242D.toInt()), null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, ir, disc)
        big.textSize = size * 0.20f
        small.textSize = size * 0.09f
        canvas.drawText(counts[0].toString(), cx, cy + big.textSize * 0.25f, big)
        canvas.drawText("plat", cx, cy + big.textSize * 0.25f + small.textSize * 1.4f, small)
    }
}
