package com.wans.platscan

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.Executors

/**
 * Alarm target di level aplikasi (bukan Activity), jadi bunyi/getar terus berjalan
 * sampai dimatikan, apa pun yang terjadi pada layar. Juga mengurus pencatatan temuan,
 * foto bukti, dan lokasi.
 */
object AlarmController {

    enum class Loc { IDLE, NEED_PERMISSION, WAITING_PERMISSION, SEARCHING, DONE, UNAVAILABLE }

    @Volatile
    var active = false
        private set

    @Volatile
    var logId = 0L
        private set

    @Volatile
    var alertShowing = false

    @Volatile
    private var dismissed = false

    val locState = MutableStateFlow(Loc.IDLE)

    private var appCtx: Context? = null
    private var player: MediaPlayer? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun init(app: Context) {
        appCtx = app.applicationContext
    }

    /** True sekali setelah alarm dimatikan; dipakai MainActivity untuk menahan alarm ulang. */
    fun consumeDismissed(): Boolean {
        val d = dismissed
        dismissed = false
        return d
    }

    /**
     * Mulai alarm + catat temuan. Dipanggil di main thread.
     * onReady(id) berjalan di main thread begitu baris riwayat tersimpan.
     */
    fun trigger(ctx: Context, log: ScanLog, snap: Evidence.Snapshot?, onReady: (Long) -> Unit) {
        val app = ctx.applicationContext
        appCtx = app
        active = true
        dismissed = false
        logId = 0L
        locState.value = Loc.IDLE
        startSound(app)
        Notifier.show(app, log)

        worker.execute {
            val dao = AppDb.get(app).logs()
            val id = try { dao.insert(log) } catch (e: Exception) { 0L }
            logId = id
            main.post {
                onReady(id)
                beginLocation(app, id)
            }
            if (id != 0L && snap != null && AlarmSettings.photo(app)) {
                val name = Evidence.save(app, snap)
                if (name != null) {
                    try { dao.setPhoto(id, name) } catch (e: Exception) { }
                }
            }
        }
    }

    fun stop() {
        val was = active
        player?.let {
            try { it.stop() } catch (_: Exception) { }
            it.release()
        }
        player = null
        (appCtx?.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.cancel()
        Notifier.cancel(appCtx)
        active = false
        if (was) dismissed = true
    }

    // ---------- Lokasi ----------

    private fun beginLocation(app: Context, id: Long) {
        when {
            id == 0L -> locState.value = Loc.UNAVAILABLE
            LocationHelper.hasPermission(app) -> startLocate(app, id)
            !prefs(app).getBoolean("loc_asked", false) -> locState.value = Loc.NEED_PERMISSION
            else -> locState.value = Loc.UNAVAILABLE
        }
    }

    /** Dipanggil layar target tepat sebelum dialog izin ditampilkan (izin hanya ditanya sekali). */
    fun permissionPrompted(ctx: Context) {
        prefs(ctx).edit().putBoolean("loc_asked", true).apply()
        locState.value = Loc.WAITING_PERMISSION
    }

    fun onPermissionResult(ctx: Context, granted: Boolean) {
        val id = logId
        if (granted && id != 0L) startLocate(ctx.applicationContext, id)
        else locState.value = Loc.UNAVAILABLE
    }

    private fun startLocate(app: Context, id: Long) {
        locState.value = Loc.SEARCHING
        var got = false
        LocationHelper.locate(
            app,
            onFix = { loc, approx ->
                got = true
                val acc = if (loc.hasAccuracy()) loc.accuracy else null
                worker.execute {
                    try {
                        AppDb.get(app).logs().setLocation(id, loc.latitude, loc.longitude, acc, approx)
                    } catch (e: Exception) { }
                }
            },
            onDone = {
                // lewat worker yang sama supaya status DONE muncul setelah data tertulis
                worker.execute {
                    main.post { locState.value = if (got) Loc.DONE else Loc.UNAVAILABLE }
                }
            }
        )
    }

    private fun prefs(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    // ---------- Suara & getar ----------

    private fun startSound(app: Context) {
        stopSoundOnly()
        val uri = Uri.parse("android.resource://${app.packageName}/${R.raw.beep}")
        if (AlarmSettings.sound(app)) {
            try {
                player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    setDataSource(app, uri)
                    setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
                    isLooping = true
                    prepare()
                    val vol = AlarmSettings.volume(app) / 100f
                    setVolume(vol, vol)
                    start()
                }
            } catch (e: Exception) {
                player?.release()
                player = null
            }
        }
        if (AlarmSettings.vibrate(app)) startVibrate(app)
    }

    /** Tes suara & getar 3 detik dari tab Setting. */
    fun preview(ctx: Context) {
        if (active) return
        val app = ctx.applicationContext
        appCtx = app
        startSound(app)
        main.removeCallbacks(previewStop)
        main.postDelayed(previewStop, 3000)
    }

    private val previewStop = Runnable {
        if (!active) {
            stopSoundOnly()
            (appCtx?.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.cancel()
        }
    }

    private fun stopSoundOnly() {
        player?.let {
            try { it.stop() } catch (_: Exception) { }
            it.release()
        }
        player = null
    }

    @Suppress("DEPRECATION")
    private fun startVibrate(app: Context) {
        val vib = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        val pattern = longArrayOf(0, 700, 400)
        if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(pattern, 0))
        else vib.vibrate(pattern, 0)
    }
}
