package com.wans.platscan

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Satu baris tampilan riwayat. header terisi pada baris pertama tiap tanggal. */
data class LogRow(val log: ScanLog, val header: String?, val count: Int)

object LogRows {
    /** [logs] harus urut terbaru dulu. Penggabungan hanya di tampilan, data tetap utuh. */
    fun build(logs: List<ScanLog>): List<LogRow> {
        val locale = Locale("id", "ID")
        val dayKey = SimpleDateFormat("yyyyMMdd", Locale.US)
        val label = SimpleDateFormat("EEEE, dd MMM yyyy", locale)
        val today = dayKey.format(Date())
        val yesterday = dayKey.format(Calendar.getInstance().apply { add(Calendar.DATE, -1) }.time)
        fun day(l: ScanLog) = dayKey.format(Date(l.scannedAt))
        fun group(l: ScanLog) =
            if (l.unregistered()) day(l) + PlateParser.key(l.plate) else "id" + l.id
        val counts = logs.groupingBy { group(it) }.eachCount()
        var lastDay = ""
        return logs.distinctBy { group(it) }.map { l ->
            val d = day(l)
            val header = if (d == lastDay) null else when (d) {
                today -> "Hari ini"
                yesterday -> "Kemarin"
                else -> label.format(Date(l.scannedAt))
            }
            lastDay = d
            LogRow(l, header, counts[group(l)] ?: 1)
        }
    }
}
