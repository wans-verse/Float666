package com.wans.platscan

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Backup/restore semua data (plat, target, riwayat, isi dropdown) ke satu file JSON. Foto bukti tidak ikut. */
object Backup {
    data class Result(
        val vNew: Int, val vUpd: Int, val tNew: Int, val tUpd: Int, val lNew: Int, val lSkip: Int
    )

    private fun JSONObject.optStr(k: String) = if (isNull(k)) "" else optString(k, "")

    fun build(c: Context): String {
        val db = AppDb.get(c)
        val root = JSONObject()
        root.put("app", "platscan")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("vehicles", JSONArray().also { a ->
            db.vehicles().list().forEach { v ->
                a.put(JSONObject().put("plateKey", v.plateKey).put("plate", v.plate).put("nama", v.nama)
                    .put("jenis", v.jenis).put("tipe", v.tipe).put("warna", v.warna).put("keterangan", v.keterangan))
            }
        })
        root.put("targets", JSONArray().also { a ->
            db.targets().list().forEach { t ->
                a.put(JSONObject().put("plateKey", t.plateKey).put("plate", t.plate).put("note", t.note)
                    .put("createdAt", t.createdAt).put("nama", t.nama).put("jenis", t.jenis)
                    .put("tipe", t.tipe).put("warna", t.warna))
            }
        })
        root.put("logs", JSONArray().also { a ->
            db.logs().list().forEach { l ->
                val o = JSONObject().put("plate", l.plate).put("nama", l.nama).put("detail", l.detail)
                    .put("scannedAt", l.scannedAt).put("isTarget", l.isTarget).put("approx", l.approx)
                    .put("ownerName", l.ownerName).put("kendaraan", l.kendaraan)
                    .put("warna", l.warna).put("catatan", l.catatan)
                l.lat?.let { o.put("lat", it) }
                l.lon?.let { o.put("lon", it) }
                l.accuracy?.let { o.put("accuracy", it.toDouble()) }
                l.address?.let { o.put("address", it) }
                a.put(o)
            }
        })
        root.put("options", Options.snapshot(c))
        return root.toString(1)
    }

    /** Gabung ke data yang ada. Lempar exception bila file bukan backup PlatScan. */
    fun restore(c: Context, text: String): Result {
        val root = JSONObject(text)
        require(root.optString("app") == "platscan") { "Bukan file backup PlatScan" }
        val db = AppDb.get(c)

        val vs = root.optJSONArray("vehicles") ?: JSONArray()
        val vList = List(vs.length()) {
            val o = vs.getJSONObject(it)
            Vehicle(o.getString("plateKey"), o.optStr("plate"), o.optStr("nama"), o.optStr("jenis"),
                o.optStr("tipe"), o.optStr("warna"), o.optStr("keterangan"))
        }
        val ts = root.optJSONArray("targets") ?: JSONArray()
        val tList = List(ts.length()) {
            val o = ts.getJSONObject(it)
            Target(o.getString("plateKey"), o.optStr("plate"), o.optStr("note"), o.optLong("createdAt"),
                o.optStr("nama"), o.optStr("jenis"), o.optStr("tipe"), o.optStr("warna"))
        }
        val ls = root.optJSONArray("logs") ?: JSONArray()
        val lList = List(ls.length()) {
            val o = ls.getJSONObject(it)
            ScanLog(
                plate = o.optStr("plate"), nama = o.optStr("nama"), detail = o.optStr("detail"),
                scannedAt = o.optLong("scannedAt"), isTarget = o.optBoolean("isTarget"),
                lat = if (o.has("lat")) o.getDouble("lat") else null,
                lon = if (o.has("lon")) o.getDouble("lon") else null,
                accuracy = if (o.has("accuracy")) o.getDouble("accuracy").toFloat() else null,
                approx = o.optBoolean("approx"), photo = null,
                address = if (o.has("address")) o.getString("address") else null,
                ownerName = o.optStr("ownerName"), kendaraan = o.optStr("kendaraan"),
                warna = o.optStr("warna"), catatan = o.optStr("catatan")
            )
        }

        var res = Result(0, 0, 0, 0, 0, 0)
        db.runInTransaction(Runnable {
            val vKeys = db.vehicles().keys().toHashSet()
            val vNew = vList.count { it.plateKey !in vKeys }
            db.vehicles().upsertAll(vList)

            val tKeys = db.targets().list().map { it.plateKey }.toHashSet()
            var tNew = 0
            tList.forEach { if (it.plateKey !in tKeys) tNew++; db.targets().upsert(it) }

            val lKeys = db.logs().list().map { "${it.scannedAt}|${it.plate}" }.toHashSet()
            var lNew = 0; var lSkip = 0
            lList.forEach {
                if (lKeys.add("${it.scannedAt}|${it.plate}")) { db.logs().insert(it); lNew++ } else lSkip++
            }
            res = Result(vNew, vList.size - vNew, tNew, tList.size - tNew, lNew, lSkip)
        })
        root.optJSONObject("options")?.let { Options.merge(c, it) }
        return res
    }
}
