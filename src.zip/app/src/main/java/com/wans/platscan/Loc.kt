package com.wans.platscan

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.core.os.CancellationSignal
import androidx.core.util.Consumer

/** GPS lewat LocationManager bawaan Android (tanpa Play Services). */
object LocationHelper {
    private const val TIMEOUT_MS = 20_000L

    fun hasFine(c: Context) = ContextCompat.checkSelfPermission(
        c, Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    fun hasCoarse(c: Context) = ContextCompat.checkSelfPermission(
        c, Manifest.permission.ACCESS_COARSE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    fun hasPermission(c: Context) = hasFine(c) || hasCoarse(c)

    /**
     * Cari lokasi satu kali. Semua callback berjalan di main thread.
     * onFix(lokasi, perkiraan): perkiraan = true bila memakai lokasi terakhir yang tersimpan.
     * Fix bisa datang lebih dari sekali (jaringan dulu, lalu GPS yang lebih akurat).
     */
    @SuppressLint("MissingPermission")
    fun locate(ctx: Context, onFix: (Location, Boolean) -> Unit, onDone: () -> Unit) {
        val app = ctx.applicationContext
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm == null) { onDone(); return }

        val wanted = if (hasFine(app)) {
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        } else {
            listOf(LocationManager.NETWORK_PROVIDER)
        }
        val providers = wanted.filter {
            try { lm.isProviderEnabled(it) } catch (e: Exception) { false }
        }

        val main = Handler(Looper.getMainLooper())
        val signal = CancellationSignal()
        var best: Location? = null
        var pending = providers.size
        var finished = false

        fun finish() {
            if (finished) return
            finished = true
            main.removeCallbacksAndMessages(null)
            try { signal.cancel() } catch (e: Exception) { }
            if (best == null) {
                val last = lastKnown(lm)
                if (last != null) onFix(last, true)
            }
            onDone()
        }

        if (providers.isEmpty()) { finish(); return }
        main.postDelayed({ finish() }, TIMEOUT_MS)

        val exec = ContextCompat.getMainExecutor(app)
        for (p in providers) {
            try {
                LocationManagerCompat.getCurrentLocation(lm, p, signal, exec, Consumer<Location?> { loc ->
                    if (finished) return@Consumer
                    pending--
                    if (loc != null) {
                        val cur = best
                        val better = cur == null ||
                            (loc.hasAccuracy() && (!cur.hasAccuracy() || loc.accuracy < cur.accuracy))
                        if (better) {
                            best = loc
                            onFix(loc, false)
                        }
                    }
                    if ((loc != null && loc.provider == LocationManager.GPS_PROVIDER) || pending <= 0) finish()
                })
            } catch (e: Exception) {
                pending--
                if (pending <= 0) finish()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun lastKnown(lm: LocationManager): Location? {
        var best: Location? = null
        for (p in listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } ?: continue
            if (best == null || l.time > best.time) best = l
        }
        return best
    }
}
