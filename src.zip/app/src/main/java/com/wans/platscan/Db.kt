package com.wans.platscan

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey val plateKey: String,
    val plate: String,
    val nama: String,
    val jenis: String,
    val tipe: String,
    val warna: String,
    val keterangan: String
)

fun Vehicle.detail(): String =
    listOf(jenis, tipe, warna).filter { it.isNotBlank() }.joinToString(" \u00B7 ")

@Entity(tableName = "scan_log")
data class ScanLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plate: String,
    val nama: String,
    val detail: String,
    val scannedAt: Long,
    @ColumnInfo(defaultValue = "0") val isTarget: Boolean = false,
    // v3: khusus temuan target
    val lat: Double? = null,
    val lon: Double? = null,
    val accuracy: Float? = null,
    @ColumnInfo(defaultValue = "0") val approx: Boolean = false,
    val photo: String? = null,
    val address: String? = null,
    @ColumnInfo(defaultValue = "''") val ownerName: String = "",
    @ColumnInfo(defaultValue = "''") val kendaraan: String = "",
    @ColumnInfo(defaultValue = "''") val warna: String = "",
    @ColumnInfo(defaultValue = "''") val catatan: String = ""
)

@Entity(tableName = "targets")
data class Target(
    @PrimaryKey val plateKey: String,
    val plate: String,
    val note: String,
    val createdAt: Long,
    @ColumnInfo(defaultValue = "''") val nama: String = "",
    @ColumnInfo(defaultValue = "''") val jenis: String = "",
    @ColumnInfo(defaultValue = "''") val tipe: String = "",
    @ColumnInfo(defaultValue = "''") val warna: String = ""
)

@Dao
interface VehicleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun upsertAll(list: List<Vehicle>)
    @Query("SELECT * FROM vehicles ORDER BY plate") fun all(): Flow<List<Vehicle>>
    @Query("SELECT plateKey FROM vehicles") fun keys(): List<String>
    @Query("SELECT * FROM vehicles") fun list(): List<Vehicle>
    @Delete fun delete(v: Vehicle)
    @Query("DELETE FROM vehicles") fun clear()
}

@Dao
interface LogDao {
    @Insert fun insert(l: ScanLog): Long
    @Query("SELECT * FROM scan_log ORDER BY scannedAt DESC") fun all(): Flow<List<ScanLog>>
    @Query("SELECT * FROM scan_log WHERE id = :id") fun watch(id: Long): Flow<ScanLog?>
    @Query("UPDATE scan_log SET lat = :lat, lon = :lon, accuracy = :accuracy, approx = :approx WHERE id = :id")
    fun setLocation(id: Long, lat: Double, lon: Double, accuracy: Float?, approx: Boolean)
    @Query("UPDATE scan_log SET photo = :photo WHERE id = :id") fun setPhoto(id: Long, photo: String)
    @Query("UPDATE scan_log SET address = :address WHERE id = :id") fun setAddress(id: Long, address: String)
    @Query("DELETE FROM scan_log") fun clear()
    @Query("DELETE FROM scan_log WHERE isTarget = 0 AND catatan = 'tidak_terdaftar' AND scannedAt < :before")
    fun deleteOldUnknown(before: Long)
    @Query("SELECT * FROM scan_log ORDER BY scannedAt") fun list(): List<ScanLog>
}

@Dao
interface TargetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun upsert(t: Target)
    @Query("SELECT * FROM targets") fun list(): List<Target>
    @Query("SELECT * FROM targets ORDER BY createdAt DESC") fun all(): Flow<List<Target>>
    @Delete fun delete(t: Target)
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `targets` (`plateKey` TEXT NOT NULL, `plate` TEXT NOT NULL, " +
                "`note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`plateKey`))"
        )
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `isTarget` INTEGER NOT NULL DEFAULT 0")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `lat` REAL")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `lon` REAL")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `accuracy` REAL")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `approx` INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `photo` TEXT")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `address` TEXT")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `ownerName` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `kendaraan` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `warna` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `scan_log` ADD COLUMN `catatan` TEXT NOT NULL DEFAULT ''")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `targets` ADD COLUMN `nama` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `targets` ADD COLUMN `jenis` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `targets` ADD COLUMN `tipe` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `targets` ADD COLUMN `warna` TEXT NOT NULL DEFAULT ''")
    }
}

@Database(entities = [Vehicle::class, ScanLog::class, Target::class], version = 4, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun vehicles(): VehicleDao
    abstract fun logs(): LogDao
    abstract fun targets(): TargetDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "plat.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                .build().also { inst = it }
        }
    }
}
