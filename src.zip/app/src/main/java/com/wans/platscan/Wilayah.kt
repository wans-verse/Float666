package com.wans.platscan

/** Kode huruf depan plat -> wilayah registrasi (ringkas). */
object Wilayah {
    private val map: Map<String, String> = """
A=Banten;B=Jakarta & sekitarnya;D=Bandung;E=Cirebon;F=Bogor/Sukabumi/Cianjur;T=Purwakarta/Karawang/Subang;Z=Priangan Timur
G=Pekalongan;H=Semarang;K=Pati;R=Banyumas;AA=Kedu;AD=Surakarta;AB=Yogyakarta
L=Surabaya;W=Sidoarjo/Gresik;M=Madura;N=Malang & sekitarnya;P=Besuki;S=Bojonegoro/Mojokerto;AE=Madiun;AG=Kediri
BL=Aceh;BB=Sumut barat;BK=Sumut timur;BA=Sumatera Barat;BM=Riau;BP=Kepulauan Riau;BH=Jambi
BG=Sumatera Selatan;BN=Bangka Belitung;BD=Bengkulu;BE=Lampung
DK=Bali;DR=Lombok;EA=Sumbawa;DH=Timor;EB=Flores;ED=Sumba
KB=Kalimantan Barat;DA=Kalimantan Selatan;KH=Kalimantan Tengah;KT=Kalimantan Timur;KU=Kalimantan Utara
DB=Manado & sekitarnya;DL=Sangihe/Talaud;DM=Gorontalo;DN=Sulawesi Tengah;DT=Sulawesi Tenggara;DC=Sulawesi Barat
DD=Makassar & sekitarnya;DP=Sulawesi Selatan;DW=Sulawesi Selatan
DE=Maluku;DG=Maluku Utara;PA=Papua;PB=Papua Barat;PY=Papua Barat Daya;PS=Papua Selatan;PT=Papua Tengah;DS=Papua (kode lama)
""".trim().split(';', '\n').associate { it.substringBefore('=') to it.substringAfter('=') }

    /** Null bila huruf depan tidak dikenal. */
    fun of(plate: String): String? = map[plate.trim().uppercase().takeWhile { it.isLetter() }]
}
