package com.wans.platscan

import android.Manifest
import android.content.Context
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.Editable
import android.util.Size
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputLayout
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private enum class Kind { IDLE, FOUND, NOT_FOUND, WARN, TARGET }

    private lateinit var vDao: VehicleDao
    private lateinit var lDao: LogDao
    private lateinit var tDao: TargetDao

    private val vAdapter = VehicleAdapter { showDetail(it) }
    private val lAdapter = LogAdapter(
        onMap = { openMap(it) },
        onShare = { shareReport(it) },
        onPhoto = { openPhoto(it) }
    )
    private val tAdapter = TargetAdapter { showTarget(it) }
    private var vehicles: List<Vehicle> = emptyList()
    private var logs: List<ScanLog> = emptyList()
    @Volatile private var byKey: Map<String, Vehicle> = emptyMap()
    @Volatile private var targetByKey: Map<String, Target> = emptyMap()

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val camExec = Executors.newSingleThreadExecutor()
    private val ioExec = Executors.newSingleThreadExecutor()
    private val geoExec = Executors.newSingleThreadExecutor()
    private val geoBusy = HashSet<Long>()
    private val geoFailed = HashSet<Long>()
    private var warnSnap: Evidence.Snapshot? = null
    private var alertDialog: BottomSheetDialog? = null
    private var alertJob: Job? = null
    private var alertPulse: ValueAnimator? = null

    private val locPerm =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            AlarmController.onPermissionResult(applicationContext, res.values.any { it })
        }

    @Volatile private var scanning = true
    private var lastRun = 0L
    private var lastLogic = 0L
    private val boxRect = android.graphics.Rect()
    private var previewScale = PreviewView.ScaleType.FILL_CENTER
    private var candidate = ""
    private var candCount = 0
    private var shownKey = ""
    private var shownAt = 0L
    private var sortMode = 0
    private val sortLabels = arrayOf(
        "Plat A\u2013Z", "Plat Z\u2013A", "Nama A\u2013Z", "Nama Z\u2013A", "Jenis kendaraan", "Warna"
    )

    private lateinit var pageScan: View
    private lateinit var plateBox: PlateBoxView
    private lateinit var boxes: List<PlateBoxView>
    private val MAX_MULTI = 3
    private val slotKeys = Array(3) { "" }
    private val slotSeen = LongArray(3)
    private val multiCount = HashMap<String, Int>()
    private val multiDone = HashMap<String, Long>()
    private val multiRecent = ArrayList<String>()
    private val pendingTargets = ArrayDeque<Triple<Target, String, Evidence.Snapshot?>>()
    private lateinit var pageData: View
    private lateinit var pageTarget: View
    private lateinit var pageLog: View
    private lateinit var pageSetting: View
    private lateinit var card: MaterialCardView
    private lateinit var tvState: TextView
    private lateinit var tvPlate: TextView
    private lateinit var tvName: TextView
    private lateinit var tvDetail: TextView
    private lateinit var tvNote: TextView
    private lateinit var btnHint: MaterialButton
    private lateinit var tvCount: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var tvLogCount: TextView
    private lateinit var tvTargetCount: TextView
    private lateinit var tvTargetEmpty: TextView
    private lateinit var etSearch: TextView

    private val camPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else toast("Izin kamera diperlukan")
        }

    private val pickCsv =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importCsv(uri)
        }

    private val saveCsv =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            if (uri != null) exportLog(uri)
        }

    private val saveBackup =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) doBackup(uri)
        }

    private val pickBackup =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) doRestore(uri)
        }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            AlarmSettings.setNotif(this, ok)
            findViewById<MaterialSwitch>(R.id.swNotif).isChecked = ok
            if (!ok) toast("Izin notifikasi ditolak")
        }

    private val pageTitles = arrayOf("Scan Plat", "Data Kendaraan", "Target Aktif", "Riwayat Scan", "Pengaturan")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ScanBoxSettings.load(applicationContext)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val db = AppDb.get(this)
        vDao = db.vehicles()
        lDao = db.logs()
        tDao = db.targets()

        pageScan = findViewById(R.id.pageScan)
        pageData = findViewById(R.id.pageData)
        pageTarget = findViewById(R.id.pageTarget)
        pageLog = findViewById(R.id.pageLog)
        pageSetting = findViewById(R.id.pageSetting)
        plateBox = findViewById(R.id.plateBox)
        val boxParent = plateBox.parent as ViewGroup
        boxes = listOf(plateBox) + List(MAX_MULTI - 1) {
            PlateBoxView(this).also { boxParent.addView(it, ViewGroup.LayoutParams(-1, -1)) }
        }
        setupSettings()
        card = findViewById(R.id.resultCard)
        tvState = findViewById(R.id.tvState)
        tvPlate = findViewById(R.id.tvPlate)
        tvName = findViewById(R.id.tvName)
        tvDetail = findViewById(R.id.tvDetail)
        tvNote = findViewById(R.id.tvNote)
        btnHint = findViewById(R.id.btnHint)
        tvCount = findViewById(R.id.tvCount)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvLogCount = findViewById(R.id.tvLogCount)
        tvTargetCount = findViewById(R.id.tvTargetCount)
        tvTargetEmpty = findViewById(R.id.tvTargetEmpty)
        etSearch = findViewById(R.id.etSearch)
        sortMode = getSharedPreferences("prefs", MODE_PRIVATE).getInt("sort", 0)
        findViewById<MaterialButton>(R.id.btnAdd).setOnClickListener { showForm(null) }
        findViewById<MaterialButton>(R.id.btnSort).setOnClickListener { chooseSort() }

        findViewById<RecyclerView>(R.id.listData).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = vAdapter
        }
        findViewById<RecyclerView>(R.id.listLog).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = lAdapter
        }
        findViewById<RecyclerView>(R.id.listTarget).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = tAdapter
        }

        listOf(R.id.navScan, R.id.navData, R.id.navTarget, R.id.navLog).forEachIndexed { i, id ->
            findViewById<View>(id).setOnClickListener { selectPage(i) }
        }
        findViewById<View>(R.id.btnGear).setOnClickListener { selectPage(4) }
        findViewById<View>(R.id.fabAdd).setOnClickListener { showAddSheet() }
        selectPage(0)

        val btnToggle = findViewById<MaterialButton>(R.id.btnToggle)
        btnToggle.setOnClickListener {
            scanning = !scanning
            btnToggle.text = if (scanning) "Jeda scan" else "Lanjutkan scan"
            if (!scanning) setCard(Kind.IDLE, "Dijeda", "", "Scan dijeda", "", "")
            else setCard(Kind.IDLE, "Menunggu plat", "", "Arahkan kamera ke plat nomor", "", "")
        }

        findViewById<MaterialButton>(R.id.btnImport).setOnClickListener { pickCsv.launch(arrayOf("*/*")) }
        findViewById<MaterialButton>(R.id.btnClearData).setOnClickListener {
            confirm("Hapus semua data kendaraan?") { ioExec.execute { vDao.clear() } }
        }
        findViewById<MaterialButton>(R.id.btnExport).setOnClickListener {
            if (logs.isEmpty()) toast("Riwayat masih kosong")
            else saveCsv.launch("riwayat_scan.csv")
        }
        findViewById<MaterialButton>(R.id.btnClearLog).setOnClickListener {
            confirm("Hapus semua riwayat scan?") {
                ioExec.execute { lDao.clear(); Evidence.clearAll(applicationContext) }
            }
        }
        findViewById<MaterialButton>(R.id.btnAddTarget).setOnClickListener { showTargetForm(null) }
        findViewById<MaterialButton>(R.id.btnPickTarget).setOnClickListener { showPicker() }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })

        findViewById<ChipGroup>(R.id.groupLogFilter).setOnCheckedStateChangeListener { _, _ -> showLogs() }

        setupLogTools()

        setCard(Kind.IDLE, "Menunggu plat", "", "Arahkan kamera ke plat nomor", "", "")

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    vDao.all().collect {
                        vehicles = it
                        byKey = it.associateBy { v -> v.plateKey }
                        applyFilter()
                        updateStats()
                    }
                }
                launch {
                    lDao.all().collect {
                        logs = it
                        showLogs()
                        resolveAddresses()
                        updateStats()
                    }
                }
                launch {
                    tDao.all().collect {
                        targetByKey = it.associateBy { t -> t.plateKey }
                        tAdapter.submitList(it)
                        tvTargetCount.text = "${it.size} target aktif"
                        tvTargetEmpty.visibility = if (it.isEmpty()) View.VISIBLE else View.GONE
                        updateStats()
                    }
                }
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    // ---------- Kamera & OCR ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewView = findViewById<PreviewView>(R.id.preview)
            previewScale = previewView.scaleType
            boxes.forEach { it.scaleType = previewScale }
            // Preview & analisis sama-sama 16:9 supaya koordinat kotak pas dengan gambar di layar.
            val preview = Preview.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                        .build()
                )
                .build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                Size(1280, 720),
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                            )
                        )
                        .build()
                )
                .build()
            analysis.setAnalyzer(camExec) { proxy ->
                val media = proxy.image
                val now = SystemClock.elapsedRealtime()
                // Kotak aktif: OCR lebih sering (250 ms) supaya kotak terasa real-time;
                // logika deteksi/alarm tetap berjalan paling cepat tiap 600 ms (lihat onText).
                val gap = if (ScanBoxSettings.show) 250L else 600L
                if (!scanning || AlarmController.active || media == null || now - lastRun < gap) {
                    proxy.close(); return@setAnalyzer
                }
                lastRun = now
                val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                recognizer.process(input)
                    .addOnSuccessListener { onText(it, media, proxy.imageInfo.rotationDegrees) }
                    .addOnCompleteListener { proxy.close() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    /** Plat harus terbaca sama 2x berturut-turut; plat yang sama tidak diproses ulang 10 detik. */
    private fun onText(res: Text, media: android.media.Image, rotation: Int) {
        if (AlarmController.active) return
        if (AlarmSettings.multi(this)) { onTextMulti(res, media, rotation); return }
        findViewById<TextView>(R.id.tvMulti).visibility = View.GONE
        val plate = PlateParser.find(res.text) ?: return
        val key = PlateParser.key(plate)

        trackBox(res, key, media, rotation)

        // Logika deteksi tetap berjarak >= 600 ms antar-pembacaan seperti sebelumnya.
        val t0 = SystemClock.elapsedRealtime()
        if (t0 - lastLogic < 600) return
        lastLogic = t0

        if (key == candidate) candCount++ else { candidate = key; candCount = 1 }
        if (candCount < 2) return

        val now = SystemClock.elapsedRealtime()
        if (key == shownKey && now - shownAt < 10_000) return
        shownKey = key; shownAt = now
        handlePlate(plate, key, media, rotation)
    }

    private fun handlePlate(plate: String, key: String, media: android.media.Image, rotation: Int) {
        // 1) Target (cocok persis) -> alarm penuh
        val target = targetByKey[key]
        if (target != null) { onTargetHit(target, plate, if (AlarmSettings.photo(this)) Evidence.snapshot(media, rotation) else null); return }

        // 2) Kendaraan terdaftar
        val v = byKey[key]
        if (v != null) { showFound(v); return }

        // Tidak terdaftar (termasuk yang mirip target) -> masuk riwayat
        val unknown = ScanLog(
            plate = plate, nama = "", detail = "",
            scannedAt = System.currentTimeMillis(), catatan = UNREGISTERED
        )
        ioExec.execute { lDao.insert(unknown) }

        // 3) Mirip target (beda 1 karakter) -> peringatan
        val simTarget = PlateParser.similar(key, targetByKey.keys)?.let { targetByKey[it] }
        if (simTarget != null) {
            setCard(Kind.WARN, "Mirip target", plate, "Mungkin ${simTarget.plate}", simTarget.note, "")
            warnSnap = if (AlarmSettings.photo(this)) Evidence.snapshot(media, rotation) else null
            btnHint.text = "Ini target, bunyikan alarm"
            btnHint.visibility = View.VISIBLE
            btnHint.setOnClickListener { onTargetHit(simTarget, simTarget.plate, warnSnap) }
            return
        }

        // 4) Tidak terdaftar (+ saran kendaraan yang mirip)
        setCard(Kind.NOT_FOUND, "Tidak terdaftar", plate, "", "", "")
        val sim = PlateParser.similar(key, byKey.keys)?.let { byKey[it] }
        if (sim != null) {
            btnHint.text = "Mungkin ${sim.plate}?"
            btnHint.visibility = View.VISIBLE
            btnHint.setOnClickListener { showFound(sim) }
        }
    }

    private fun onTextMulti(res: Text, media: android.media.Image, rotation: Int) {
        // Target didahulukan supaya tidak tersingkir oleh batas 3 plat.
        val plates = PlateParser.findAll(res)
            .sortedByDescending { targetByKey.containsKey(PlateParser.key(it)) }
            .take(MAX_MULTI)
        if (plates.isEmpty()) return
        trackMulti(res, plates.map { PlateParser.key(it) }, media, rotation)

        val now = SystemClock.elapsedRealtime()
        if (now - lastLogic < 600) return
        lastLogic = now

        // Hitungan per plat; yang hilang dari pembacaan ini diulang dari nol.
        val keys = plates.map { PlateParser.key(it) }
        multiCount.keys.retainAll(keys.toSet())
        for (k in keys) multiCount[k] = (multiCount[k] ?: 0) + 1

        val ready = plates.filter {
            val k = PlateParser.key(it)
            val last = multiDone[k]
            (multiCount[k] ?: 0) >= 2 && (last == null || now - last >= 10_000)
        }
        if (ready.isEmpty()) return
        for (p in ready) multiDone[PlateParser.key(p)] = now

        val (targets, others) = ready.partition { targetByKey.containsKey(PlateParser.key(it)) }
        // Yang mirip target diproses terakhir supaya tombol peringatannya tetap tampil.
        others.sortedBy {
            val k = PlateParser.key(it)
            !byKey.containsKey(k) && PlateParser.similar(k, targetByKey.keys) != null
        }.forEach { handlePlate(it, PlateParser.key(it), media, rotation) }

        // Target ke-2 dan seterusnya diantrekan sampai alarm sebelumnya dimatikan.
        val snap = if (targets.isNotEmpty() && AlarmSettings.photo(this)) Evidence.snapshot(media, rotation) else null
        for (p in targets) {
            val t = targetByKey[PlateParser.key(p)] ?: continue
            pendingTargets.add(Triple(t, p, snap))
        }
        nextTarget()

        for (p in ready) {
            val k = PlateParser.key(p)
            val status = when {
                targetByKey.containsKey(k) -> "TARGET"
                byKey.containsKey(k) -> "Terdaftar"
                PlateParser.similar(k, targetByKey.keys) != null -> "Mirip target"
                else -> "Tidak terdaftar"
            }
            multiRecent.removeAll { it.startsWith("$p:") }
            multiRecent.add(0, "$p: $status")
        }
        while (multiRecent.size > MAX_MULTI) multiRecent.removeAt(multiRecent.lastIndex)
        findViewById<TextView>(R.id.tvMulti).apply {
            text = multiRecent.joinToString("\n")
            setTextColor(findViewById<TextView>(R.id.tvState).currentTextColor)
            visibility = View.VISIBLE
        }
    }

    private fun nextTarget() {
        if (AlarmController.active || alertDialog != null || isFinishing || isDestroyed) return
        val (t, plate, snap) = pendingTargets.removeFirstOrNull() ?: return
        onTargetHit(t, plate, snap)
    }

    /** Satu kotak per plat; plat yang sama tetap memakai kotak yang sama. */
    private fun trackMulti(res: Text, keys: List<String>, media: android.media.Image, rotation: Int) {
        if (!ScanBoxSettings.show) return
        val now = SystemClock.elapsedRealtime()
        for (i in slotKeys.indices) if (slotKeys[i] in keys) slotSeen[i] = now
        for (key in keys) {
            var i = slotKeys.indexOf(key)
            if (i < 0) {
                i = slotSeen.indices.filter { slotKeys[it] !in keys }.minByOrNull { slotSeen[it] } ?: continue
                slotKeys[i] = key
                slotSeen[i] = now
            }
            trackBox(res, key, media, rotation, boxes[i])
        }
    }

    /** Pindahkan kotak ke posisi plat (koordinat gambar tegak -> koordinat PreviewView). */
    private fun trackBox(res: Text, key: String, media: android.media.Image, rotation: Int, view: PlateBoxView = plateBox) {
        if (!ScanBoxSettings.show) return
        if (!PlateParser.findBox(res, key, boxRect)) return
        val swap = rotation % 180 != 0
        val w = if (swap) media.height else media.width
        val h = if (swap) media.width else media.height
        val st = when {
            targetByKey.containsKey(key) -> PlateBoxView.TARGET
            byKey.containsKey(key) -> PlateBoxView.FOUND
            PlateParser.similar(key, targetByKey.keys) != null -> PlateBoxView.WARN
            else -> PlateBoxView.NOT_FOUND
        }
        view.track(boxRect.left, boxRect.top, boxRect.right, boxRect.bottom, w, h, st)
    }

    private fun showFound(v: Vehicle) {
        setCard(Kind.FOUND, "Terdaftar", v.plate, v.nama, v.detail(), v.keterangan)
        val log = ScanLog(
            plate = v.plate, nama = v.nama, detail = v.detail(),
            scannedAt = System.currentTimeMillis()
        )
        ioExec.execute { lDao.insert(log) }
    }

    private fun setCard(kind: Kind, state: String, plate: String, name: String, detail: String, note: String) {
        val bgAttr: Int
        val fgAttr: Int
        when (kind) {
            Kind.FOUND -> {
                bgAttr = com.google.android.material.R.attr.colorPrimaryContainer
                fgAttr = com.google.android.material.R.attr.colorOnPrimaryContainer
            }
            Kind.NOT_FOUND -> {
                bgAttr = com.google.android.material.R.attr.colorErrorContainer
                fgAttr = com.google.android.material.R.attr.colorOnErrorContainer
            }
            Kind.WARN -> {
                bgAttr = com.google.android.material.R.attr.colorTertiaryContainer
                fgAttr = com.google.android.material.R.attr.colorOnTertiaryContainer
            }
            Kind.TARGET -> {
                bgAttr = com.google.android.material.R.attr.colorError
                fgAttr = com.google.android.material.R.attr.colorOnError
            }
            Kind.IDLE -> {
                bgAttr = com.google.android.material.R.attr.colorSurfaceVariant
                fgAttr = com.google.android.material.R.attr.colorOnSurfaceVariant
            }
        }
        card.setCardBackgroundColor(MaterialColors.getColor(card, bgAttr))
        val asal = Wilayah.of(plate)?.let { "Asal: $it" }.orEmpty()
        val noteAsal = listOf(asal, note).filter { it.isNotBlank() }.joinToString(" \u00B7 ")
        val fg = MaterialColors.getColor(card, fgAttr)
        for (t in listOf(tvState, tvPlate, tvName, tvDetail, tvNote)) t.setTextColor(fg)

        fun TextView.put(s: String) {
            text = s
            visibility = if (s.isBlank()) View.GONE else View.VISIBLE
        }
        tvState.put(state); tvPlate.put(plate); tvName.put(name)
        tvDetail.put(detail); tvNote.put(noteAsal)
        btnHint.visibility = View.GONE
    }

    // ---------- Target & alarm ----------

    private fun saveTarget(t: Target) {
        ioExec.execute { tDao.upsert(t) }
        toast("Target dikunci: ${t.plate}")
    }

    private fun lockFromVehicle(v: Vehicle) {
        saveTarget(
            Target(
                plateKey = v.plateKey, plate = v.plate, note = v.keterangan,
                createdAt = System.currentTimeMillis(),
                nama = v.nama, jenis = v.jenis, tipe = v.tipe, warna = v.warna
            )
        )
    }

    private fun showTarget(t: Target) {
        val kend = listOf(t.jenis, t.tipe).filter { it.isNotBlank() }.joinToString(" \u00B7 ")
        fun line(label: String, s: String) = if (s.isBlank()) "" else "$label: $s\n"
        val body = (line("Nama", t.nama) + line("Kendaraan", kend) + line("Warna", t.warna) +
            line("Catatan", t.note)).trim().ifEmpty { "Tanpa data tambahan" }
        MaterialAlertDialogBuilder(this)
            .setTitle(t.plate)
            .setMessage(body)
            .setPositiveButton("Tutup", null)
            .setNeutralButton("Edit") { _, _ -> showTargetForm(t) }
            .setNegativeButton("Hapus target") { _, _ -> ioExec.execute { tDao.delete(t) } }
            .show()
    }

    /** Form tambah (editing == null) atau edit target; kolomnya sama dengan data kendaraan. */
    private fun showTargetForm(editing: Target?) {
        val view = layoutInflater.inflate(R.layout.dialog_vehicle, null)
        fun f(id: Int) = view.findViewById<TextView>(id)
        val til = view.findViewById<TextInputLayout>(R.id.tilFPlate)
        if (editing != null) {
            f(R.id.etFPlate).text = editing.plate
            f(R.id.etFNama).text = editing.nama
            f(R.id.etFJenis).text = editing.jenis
            f(R.id.etFTipe).text = editing.tipe
            f(R.id.etFWarna).text = editing.warna
            f(R.id.etFKet).text = editing.note
        }
        bindOptionFields(view)
        val dlg: AlertDialog = MaterialAlertDialogBuilder(this)
            .setTitle(if (editing == null) "Tambah target" else "Edit target")
            .setView(view)
            .setPositiveButton("Kunci target", null)
            .setNegativeButton("Batal", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = f(R.id.etFPlate).text.toString().trim()
                val key = PlateParser.key(raw)
                if (key.length < 3) { til.error = "Isi plat dengan benar"; return@setOnClickListener }
                til.error = null
                val nt = Target(
                    plateKey = key,
                    plate = PlateParser.format(raw),
                    note = f(R.id.etFKet).text.toString().trim(),
                    createdAt = editing?.createdAt ?: System.currentTimeMillis(),
                    nama = f(R.id.etFNama).text.toString().trim(),
                    jenis = f(R.id.etFJenis).text.toString().trim(),
                    tipe = f(R.id.etFTipe).text.toString().trim(),
                    warna = f(R.id.etFWarna).text.toString().trim()
                )
                ioExec.execute {
                    if (editing != null && editing.plateKey != key) tDao.delete(editing)
                    tDao.upsert(nt)
                }
                dlg.dismiss()
                toast("Target dikunci: ${nt.plate}")
            }
        }
        dlg.show()
    }

    /** Pilih target langsung dari database kendaraan. */
    private fun showPicker() {
        val sheet = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.sheet_pick, null)
        val et = view.findViewById<TextView>(R.id.etPick)
        val empty = view.findViewById<TextView>(R.id.tvPickEmpty)
        val list = view.findViewById<RecyclerView>(R.id.listPick)
        val ad = VehicleAdapter { v -> sheet.dismiss(); lockFromVehicle(v) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = ad
        fun filter() {
            val q = et.text.toString().trim().lowercase()
            val res = vehicles.filter {
                q.isEmpty() || listOf(it.plate, it.nama, it.jenis, it.tipe, it.warna, it.keterangan)
                    .any { f -> f.lowercase().contains(q) }
            }.sortedBy { it.plateKey }
            ad.submitList(res)
            empty.visibility = if (vehicles.isEmpty()) View.VISIBLE else View.GONE
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        filter()
        sheet.setContentView(view)
        sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        sheet.show()
    }

    private fun onTargetHit(t: Target, plate: String, snap: Evidence.Snapshot?) {
        if (AlarmController.active) return
        val v = byKey[t.plateKey]
        val nama = t.nama.ifBlank { v?.nama.orEmpty() }
        val jenis = t.jenis.ifBlank { v?.jenis.orEmpty() }
        val tipe = t.tipe.ifBlank { v?.tipe.orEmpty() }
        val warna = t.warna.ifBlank { v?.warna.orEmpty() }
        val kendaraan = listOf(jenis, tipe).filter { it.isNotBlank() }.joinToString(" \u00B7 ")
        val info = listOf(nama, listOf(jenis, tipe, warna).filter { it.isNotBlank() }.joinToString(" \u00B7 "))
            .filter { it.isNotBlank() }.joinToString(" \u00B7 ")
        val catatan = listOfNotNull(
            t.note.trim().takeIf { it.isNotBlank() && !it.equals(nama.trim(), ignoreCase = true) },
            v?.keterangan?.trim()?.takeIf { it.isNotBlank() }
        ).distinct().joinToString(" \u00B7 ")

        setCard(Kind.TARGET, "TARGET DITEMUKAN", plate, nama.ifBlank { t.note }, info, "")
        val log = ScanLog(
            plate = plate, nama = t.note.ifBlank { info }, detail = info,
            scannedAt = System.currentTimeMillis(), isTarget = true,
            ownerName = if (nama.isBlank()) "" else Fmt.titleCase(nama),
            kendaraan = kendaraan, warna = warna, catatan = catatan
        )
        AlarmController.trigger(applicationContext, log, snap) { id ->
            if (!isFinishing && !isDestroyed) showTargetSheet(id)
        }
    }

    /** Dialog putih di bawah; alarm tetap bunyi sampai tombol "Matikan alarm" ditekan. */
    private fun showTargetSheet(logId: Long) {
        if (alertDialog != null || !AlarmController.active) return
        val dlg = BottomSheetDialog(this, R.style.SheetWhite)
        val view = layoutInflater.inflate(R.layout.sheet_alert, null)
        val rows = view.findViewById<LinearLayout>(R.id.alertRows)
        fun addRow(label: String): TextView {
            val row = layoutInflater.inflate(R.layout.item_alert_row, rows, false)
            row.findViewById<TextView>(R.id.tvRowLabel).text = label
            rows.addView(row)
            return row.findViewById(R.id.tvRowValue)
        }
        val tvPlateA = view.findViewById<TextView>(R.id.tvAlertPlate)
        val vAsal = addRow("Asal plat")
        val vNama = addRow("Nama")
        val vKend = addRow("Kendaraan")
        val vWarna = addRow("Warna")
        val vCatatan = addRow("Catatan")
        val vJam = addRow("Jam")
        val vLokasi = addRow("Lokasi")
        var cur: ScanLog? = null

        fun dash(s: String?) = if (s.isNullOrBlank()) "-" else s
        fun locText(l: ScanLog?): String {
            val lat = l?.lat
            val lon = l?.lon
            if (l != null && lat != null && lon != null) {
                val sb = StringBuilder(Fmt.coords(lat, lon))
                val acc = Fmt.accuracy(l.accuracy)
                if (acc.isNotEmpty()) sb.append("\nakurasi ").append(acc)
                if (l.approx) sb.append("\nperkiraan (lokasi terakhir)")
                return sb.toString()
            }
            return when (AlarmController.locState.value) {
                AlarmController.Loc.UNAVAILABLE -> "Lokasi tidak tersedia"
                AlarmController.Loc.NEED_PERMISSION,
                AlarmController.Loc.WAITING_PERMISSION -> "Menunggu izin lokasi\u2026"
                else -> "Mencari lokasi\u2026"
            }
        }
        fun render() {
            val l = cur
            tvPlateA.text = l?.plate.orEmpty()
            vAsal.text = dash(l?.let { Wilayah.of(it.plate) })
            vNama.text = dash(l?.displayName())
            vKend.text = dash(l?.displayKendaraan())
            vWarna.text = dash(l?.warna)
            vCatatan.text = dash(l?.catatan)
            vJam.text = if (l == null) "-" else Fmt.time(l.scannedAt)
            vLokasi.text = locText(l)
        }
        render()

        view.findViewById<MaterialButton>(R.id.btnStop).setOnClickListener {
            AlarmController.stop()
            dlg.dismiss()
        }
        view.findViewById<MaterialButton>(R.id.btnShare).setOnClickListener {
            val l = cur
            if (l == null) toast("Data belum siap") else shareReport(l)
        }

        dlg.setContentView(view)
        dlg.setCancelable(false)
        dlg.setCanceledOnTouchOutside(false)
        dlg.behavior.isDraggable = false
        dlg.behavior.skipCollapsed = true
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED

        // Penanda "!" berdenyut lewat perubahan warna
        val badge = view.findViewById<MaterialCardView>(R.id.alertBadge)
        alertPulse = ValueAnimator.ofObject(
            ArgbEvaluator(),
            ContextCompat.getColor(this, R.color.alarm_red_a),
            ContextCompat.getColor(this, R.color.alarm_red_b)
        ).apply {
            duration = 650
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { va -> badge.setCardBackgroundColor(va.animatedValue as Int) }
            start()
        }

        alertJob = lifecycleScope.launch {
            launch {
                lDao.watch(logId).collect { cur = it; render() }
            }
            launch {
                AlarmController.locState.collect { st ->
                    render()
                    if (st == AlarmController.Loc.NEED_PERMISSION) {
                        AlarmController.permissionPrompted(applicationContext)
                        locPerm.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    }
                }
            }
        }

        dlg.setOnDismissListener {
            alertPulse?.cancel(); alertPulse = null
            alertJob?.cancel(); alertJob = null
            alertDialog = null
            AlarmController.alertShowing = false
            if (!AlarmController.active) {
                // Tahan alarm ulang 10 detik untuk plat yang baru dimatikan, lalu lanjut antrean.
                cur?.let { multiDone[PlateParser.key(it.plate)] = SystemClock.elapsedRealtime() }
                window.decorView.post { nextTarget() }
            }
        }
        alertDialog = dlg
        AlarmController.alertShowing = true
        dlg.show()
    }

    private fun openPhoto(l: ScanLog) {
        val name = l.photo ?: return
        startActivity(Intent(this, PhotoActivity::class.java).putExtra(PhotoActivity.EXTRA_FILE, name))
    }

    /** Cari alamat (Geocoder) untuk temuan yang sudah punya koordinat, hanya bila ada internet. */
    private fun resolveAddresses() {
        if (!Net.online(this)) return
        for (l in logs) {
            val lat = l.lat ?: continue
            val lon = l.lon ?: continue
            if (!l.address.isNullOrBlank() || l.id in geoFailed || !geoBusy.add(l.id)) continue
            geoExec.execute {
                val addr = Geo.lookup(applicationContext, lat, lon)
                if (addr != null) lDao.setAddress(l.id, addr)
                runOnUiThread {
                    geoBusy.remove(l.id)
                    if (addr == null) geoFailed.add(l.id)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (AlarmController.consumeDismissed()) shownAt = SystemClock.elapsedRealtime()
        // Layar target hilang (mis. dimatikan sistem) tapi alarm masih aktif: tampilkan lagi.
        if (AlarmController.active && alertDialog == null && AlarmController.logId != 0L) {
            showTargetSheet(AlarmController.logId)
        }
    }



    // ---------- Navigasi & statistik ----------

    private fun selectPage(i: Int) {
        pageScan.visibility = if (i == 0) View.VISIBLE else View.GONE
        pageData.visibility = if (i == 1) View.VISIBLE else View.GONE
        pageTarget.visibility = if (i == 2) View.VISIBLE else View.GONE
        pageLog.visibility = if (i == 3) View.VISIBLE else View.GONE
        pageSetting.visibility = if (i == 4) View.VISIBLE else View.GONE
        listOf(R.id.navScan, R.id.navData, R.id.navTarget, R.id.navLog).forEachIndexed { k, id ->
            findViewById<View>(id).isSelected = (k == i)
        }
        findViewById<View>(R.id.statsBlock).visibility = if (i in 1..3) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.tvPanelTitle).text = pageTitles[i]
        if (i == 3) { geoFailed.clear(); resolveAddresses() }
        if (i == 4) refreshSettings()
    }

    private fun updateStats() {
        findViewById<RingView>(R.id.ringView).set(vehicles.size, targetByKey.size, logs.size)
        findViewById<TextView>(R.id.tvLegData).text = vehicles.size.toString()
        findViewById<TextView>(R.id.tvLegTarget).text = targetByKey.size.toString()
        findViewById<TextView>(R.id.tvLegLog).text = logs.size.toString()
    }

    private fun showAddSheet() {
        val sheet = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_add, null)
        v.findViewById<View>(R.id.btnAddVehicle).setOnClickListener { sheet.dismiss(); showForm(null) }
        v.findViewById<View>(R.id.btnAddTargetSheet).setOnClickListener { sheet.dismiss(); showTargetForm(null) }
        sheet.setContentView(v)
        sheet.show()
    }

    // ---------- Pilihan jenis / tipe / warna (chip) ----------

    /** Jenis & warna berupa chip, tipe lewat kartu pencarian; tipe mengikuti jenis. */
    private fun bindOptionFields(view: View) {
        fun tv(id: Int) = view.findViewById<TextView>(id)
        val jenis = tv(R.id.etFJenis); val tipe = tv(R.id.etFTipe); val warna = tv(R.id.etFWarna)
        val tipeVal = tv(R.id.tvTipeVal)
        val gJ = view.findViewById<ChipGroup>(R.id.groupJenis)
        val gW = view.findViewById<ChipGroup>(R.id.groupWarna)
        fun cur(t: TextView) = t.text.toString().trim()

        fun showTipe() {
            val t = cur(tipe)
            tipeVal.text = t.ifEmpty { "Pilih tipe" }
            tipeVal.alpha = if (t.isEmpty()) 0.6f else 1f
        }

        fun optChip(label: String, checked: Boolean, swatch: Boolean): Chip = Chip(this).apply {
            text = label
            isCheckable = true
            isChecked = checked
            chipIconTint = null
            if (swatch) {
                chipIcon = Options.dot(Options.colorFor(label), this@MainActivity)
                isChipIconVisible = true
            }
        }
        fun addChip(label: String, onClick: () -> Unit): Chip = Chip(this).apply {
            text = label
            isCheckable = false
            chipIcon = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_add)
            isChipIconVisible = true
            chipIconTint = null
            setOnClickListener { onClick() }
        }

        fun rebuildJenis() {
            gJ.removeAllViews()
            val c = cur(jenis)
            val list = Options.jenis(this).toMutableList()
            if (c.isNotEmpty() && list.none { it.equals(c, true) }) list.add(c)
            for (j in list) {
                val chip = optChip(j, j.equals(c, true), false)
                chip.setOnCheckedChangeListener { _, on ->
                    if (on) {
                        jenis.text = j
                        if (cur(tipe) !in Options.tipe(this, j)) tipe.text = ""
                        showTipe()
                    } else if (cur(jenis) == j) {
                        jenis.text = ""; tipe.text = ""; showTipe()
                    }
                }
                gJ.addView(chip)
            }
            gJ.addView(addChip("Jenis") {
                showOptionSheet("Tambah jenis", { Options.jenis(this) },
                    onAdd = { Options.addJenis(this, it) },
                    onPick = { v ->
                        jenis.text = v
                        if (cur(tipe) !in Options.tipe(this, v)) tipe.text = ""
                        showTipe(); rebuildJenis()
                    })
            })
        }

        fun rebuildWarna() {
            gW.removeAllViews()
            val c = cur(warna)
            val list = Options.warna(this).toMutableList()
            if (c.isNotEmpty() && list.none { it.equals(c, true) }) list.add(c)
            for (w in list) {
                val chip = optChip(w, w.equals(c, true), true)
                chip.setOnCheckedChangeListener { _, on ->
                    if (on) warna.text = w else if (cur(warna) == w) warna.text = ""
                }
                gW.addView(chip)
            }
            gW.addView(addChip("Warna") {
                showOptionSheet("Tambah warna", { Options.warna(this) },
                    onAdd = { Options.addWarna(this, it) },
                    onPick = { v -> warna.text = v; rebuildWarna() },
                    swatch = true)
            })
        }

        view.findViewById<View>(R.id.cardTipe).setOnClickListener {
            val j = cur(jenis)
            if (j.isEmpty()) { toast("Pilih jenis kendaraan dulu"); return@setOnClickListener }
            showOptionSheet("Tipe $j", { Options.tipe(this, j) }, cur(tipe),
                onAdd = { Options.addTipe(this, j, it) },
                onClear = { tipe.text = ""; showTipe() },
                onPick = { tipe.text = it; showTipe() })
        }
        rebuildJenis(); rebuildWarna(); showTipe()
    }

    private fun setupSettings() {
        findViewById<View>(R.id.rowSetJenis).setOnClickListener {
            showOptionSheet("Kelola jenis", { Options.jenis(this) },
                onAdd = { Options.addJenis(this, it) },
                onRemove = { Options.removeJenis(this, it) },
                onChanged = { refreshSettings() })
        }
        findViewById<View>(R.id.rowSetTipe).setOnClickListener {
            showOptionSheet("Tipe untuk jenis apa?", { Options.jenis(this) },
                onPick = { j ->
                    showOptionSheet("Kelola tipe $j", { Options.tipe(this, j) },
                        onAdd = { Options.addTipe(this, j, it) },
                        onRemove = { Options.removeTipe(this, j, it) },
                        onChanged = { refreshSettings() })
                })
        }
        findViewById<View>(R.id.rowSetWarna).setOnClickListener {
            showOptionSheet("Kelola warna", { Options.warna(this) },
                onAdd = { Options.addWarna(this, it) },
                onRemove = { Options.removeWarna(this, it) },
                onChanged = { refreshSettings() },
                swatch = true)
        }

        // Suara, getar, notifikasi
        val swSound = findViewById<MaterialSwitch>(R.id.swSound)
        val swVib = findViewById<MaterialSwitch>(R.id.swVibrate)
        val swNotif = findViewById<MaterialSwitch>(R.id.swNotif)
        swSound.isChecked = AlarmSettings.sound(this)
        swVib.isChecked = AlarmSettings.vibrate(this)
        swNotif.isChecked = AlarmSettings.notif(this) && AlarmSettings.hasNotifPermission(this)
        swSound.setOnCheckedChangeListener { _, on -> AlarmSettings.setSound(this, on) }
        swVib.setOnCheckedChangeListener { _, on -> AlarmSettings.setVibrate(this, on) }
        swNotif.setOnCheckedChangeListener { _, on ->
            if (on && !AlarmSettings.hasNotifPermission(this)) {
                if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else AlarmSettings.setNotif(this, on)
        }

        val slider = findViewById<Slider>(R.id.sliderVol)
        val volLabel = findViewById<TextView>(R.id.tvVolLabel)
        slider.value = AlarmSettings.volume(this).toFloat().coerceIn(10f, 100f)
        volLabel.text = "Volume alarm ${slider.value.toInt()}%"
        slider.addOnChangeListener { _, v, fromUser ->
            volLabel.text = "Volume alarm ${v.toInt()}%"
            if (fromUser) AlarmSettings.setVolume(this, v.toInt())
        }
        val swMulti = findViewById<MaterialSwitch>(R.id.swMulti)
        swMulti.isChecked = AlarmSettings.multi(this)
        swMulti.setOnCheckedChangeListener { _, on ->
            AlarmSettings.setMulti(this, on)
            multiCount.clear(); multiRecent.clear()
            findViewById<TextView>(R.id.tvMulti).visibility = View.GONE
        }
        val swPhoto = findViewById<MaterialSwitch>(R.id.swPhoto)
        swPhoto.isChecked = AlarmSettings.photo(this)
        swPhoto.setOnCheckedChangeListener { _, on -> AlarmSettings.setPhoto(this, on) }
        findViewById<View>(R.id.btnTestAlarm).setOnClickListener { AlarmController.preview(this) }

        findViewById<MaterialButton>(R.id.btnBackup).setOnClickListener {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            saveBackup.launch("platscan_backup_$stamp.json")
        }
        findViewById<MaterialButton>(R.id.btnRestore).setOnClickListener {
            pickBackup.launch(arrayOf("application/json", "text/plain", "*/*"))
        }
        setupBoxSettings()
        refreshSettings()
    }

    /** Bagian "KOTAK SCAN": tampil/sembunyi, ketebalan, warna + pratinjau. Berlaku langsung. */
    private fun setupBoxSettings() {
        val sw = findViewById<MaterialSwitch>(R.id.swBox)
        val slider = findViewById<Slider>(R.id.sliderBoxWidth)
        val label = findViewById<TextView>(R.id.tvBoxWidth)
        val group = findViewById<ChipGroup>(R.id.groupBoxColor)
        val prev = findViewById<PlateBoxView>(R.id.boxPreview)
        prev.previewMode = true
        fun applyAll() { boxes.forEach { it.refresh() }; prev.refresh() }

        sw.isChecked = ScanBoxSettings.show
        sw.setOnCheckedChangeListener { _, on ->
            ScanBoxSettings.setShow(this, on)
            applyAll()
        }

        slider.valueFrom = ScanBoxSettings.MIN_DP.toFloat()
        slider.valueTo = ScanBoxSettings.MAX_DP.toFloat()
        slider.stepSize = 1f
        slider.value = ScanBoxSettings.widthDp.toFloat()
        label.text = "Ketebalan garis ${ScanBoxSettings.widthDp} dp"
        slider.addOnChangeListener { _, v, fromUser ->
            label.text = "Ketebalan garis ${v.toInt()} dp"
            if (fromUser) {
                ScanBoxSettings.setWidth(this, v.toInt())
                applyAll()
            }
        }

        fun colorChip(key: String, text: String, color: Int?): Chip = Chip(this).apply {
            this.text = text
            isCheckable = true
            chipIconTint = null
            if (color != null) {
                chipIcon = Options.dot(color, this@MainActivity)
            } else {
                chipIcon = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_palette)
                chipIconTint = ContextCompat.getColorStateList(this@MainActivity, R.color.chip_text)
            }
            isChipIconVisible = true
            isChecked = (ScanBoxSettings.colorKey == key)
            setOnCheckedChangeListener { _, on ->
                if (on) {
                    ScanBoxSettings.setColor(this@MainActivity, key)
                    applyAll()
                }
            }
        }
        group.removeAllViews()
        group.addView(colorChip(ScanBoxSettings.AUTO, "Otomatis sesuai status", null))
        for ((key, name, color) in ScanBoxSettings.colors) group.addView(colorChip(key, name, color))

        applyAll()
    }

    private fun refreshSettings() {
        val last = getSharedPreferences("prefs", MODE_PRIVATE).getLong("lastBackup", 0L)
        findViewById<TextView>(R.id.tvLastBackup).text =
            "Plat, target, riwayat, dan isi dropdown jadi satu file (foto bukti tidak ikut).\n" +
                if (last == 0L) "Belum pernah backup." else "Backup terakhir: " +
                    SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(last))
        val js = Options.jenis(this)
        findViewById<TextView>(R.id.tvSetJenis).text =
            "${js.size} jenis: " + js.joinToString(", ").ifEmpty { "-" }
        findViewById<TextView>(R.id.tvSetTipe).text =
            js.joinToString("  \u00B7  ") { "$it ${Options.tipe(this, it).size}" }.ifEmpty { "-" }
        val ws = Options.warna(this)
        findViewById<TextView>(R.id.tvSetWarna).text =
            "${ws.size} warna: " + ws.joinToString(", ").ifEmpty { "-" }
    }

    private fun doBackup(uri: Uri) {
        ioExec.execute {
            try {
                val json = Backup.build(applicationContext)
                contentResolver.openOutputStream(uri, "wt")!!.bufferedWriter().use { it.write(json) }
                getSharedPreferences("prefs", MODE_PRIVATE).edit()
                    .putLong("lastBackup", System.currentTimeMillis()).apply()
                runOnUiThread { toast("Backup tersimpan"); refreshSettings() }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal backup: ${e.message}") }
            }
        }
    }

    private fun doRestore(uri: Uri) {
        ioExec.execute {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                val r = Backup.restore(applicationContext, text)
                runOnUiThread {
                    refreshSettings()
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Restore selesai")
                        .setMessage(
                            "Plat: ${r.vNew} baru, ${r.vUpd} diperbarui\n" +
                                "Target: ${r.tNew} baru, ${r.tUpd} diperbarui\n" +
                                "Riwayat: ${r.lNew} baru, ${r.lSkip} dilewati (sudah ada)\n" +
                                "Isi dropdown digabung."
                        )
                        .setPositiveButton("OK", null)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal restore: ${e.message}") }
            }
        }
    }

    // ---------- Data ----------

    private fun applyFilter() {
        val q = etSearch.text.toString().trim().lowercase()
        val filtered = if (q.isEmpty()) vehicles else vehicles.filter {
            listOf(it.plate, it.nama, it.jenis, it.tipe, it.warna, it.keterangan)
                .any { f -> f.lowercase().contains(q) }
        }
        val sorted = when (sortMode) {
            1 -> filtered.sortedByDescending { it.plateKey }
            2 -> filtered.sortedWith(compareBy<Vehicle> { it.nama.isBlank() }.thenBy { it.nama.lowercase() }.thenBy { it.plateKey })
            3 -> filtered.sortedWith(compareBy<Vehicle> { it.nama.isBlank() }.thenByDescending { it.nama.lowercase() }.thenBy { it.plateKey })
            4 -> filtered.sortedWith(compareBy<Vehicle> { it.jenis.isBlank() }.thenBy { it.jenis.lowercase() }.thenBy { it.plateKey })
            5 -> filtered.sortedWith(compareBy<Vehicle> { it.warna.isBlank() }.thenBy { it.warna.lowercase() }.thenBy { it.plateKey })
            else -> filtered.sortedBy { it.plateKey }
        }
        vAdapter.submitList(sorted)
        val count = if (q.isEmpty()) "${vehicles.size} kendaraan"
        else "${filtered.size} dari ${vehicles.size} kendaraan"
        tvCount.text = "$count \u00B7 ${sortLabels[sortMode]}"
        tvEmpty.visibility = if (vehicles.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun chooseSort() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Urutkan berdasarkan")
            .setSingleChoiceItems(sortLabels, sortMode) { d, which ->
                sortMode = which
                getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("sort", which).apply()
                applyFilter()
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showDetail(v: Vehicle) {
        val sheet = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.sheet_vehicle, null)
        fun line(label: String, s: String) = if (s.isBlank()) "" else "$label: $s\n"
        val body = line("Nama", v.nama) + line("Jenis kendaraan", v.jenis) +
            line("Tipe", v.tipe) + line("Warna", v.warna) + line("Keterangan", v.keterangan)
        view.findViewById<TextView>(R.id.tvSheetPlate).text = v.plate
        view.findViewById<TextView>(R.id.tvSheetBody).text = body.trim().ifEmpty { "Tidak ada data tambahan" }
        view.findViewById<MaterialButton>(R.id.btnSheetEdit).setOnClickListener {
            sheet.dismiss(); showForm(v)
        }
        view.findViewById<MaterialButton>(R.id.btnSheetDelete).setOnClickListener {
            sheet.dismiss()
            confirm("Hapus ${v.plate}?") { ioExec.execute { vDao.delete(v) } }
        }
        view.findViewById<MaterialButton>(R.id.btnSheetTarget).setOnClickListener {
            sheet.dismiss(); lockFromVehicle(v)
        }
        sheet.setContentView(view)
        sheet.show()
    }

    /** Form tambah (editing == null) atau edit kendaraan. */
    private fun showForm(editing: Vehicle?) {
        val view = layoutInflater.inflate(R.layout.dialog_vehicle, null)
        fun f(id: Int) = view.findViewById<TextView>(id)
        val til = view.findViewById<TextInputLayout>(R.id.tilFPlate)
        if (editing != null) {
            f(R.id.etFPlate).text = editing.plate
            f(R.id.etFNama).text = editing.nama
            f(R.id.etFJenis).text = editing.jenis
            f(R.id.etFTipe).text = editing.tipe
            f(R.id.etFWarna).text = editing.warna
            f(R.id.etFKet).text = editing.keterangan
        }
        bindOptionFields(view)
        val dlg: AlertDialog = MaterialAlertDialogBuilder(this)
            .setTitle(if (editing == null) "Tambah kendaraan" else "Edit kendaraan")
            .setView(view)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = f(R.id.etFPlate).text.toString().trim()
                val key = PlateParser.key(raw)
                if (key.length < 3) { til.error = "Isi plat dengan benar"; return@setOnClickListener }
                if (key != editing?.plateKey && byKey.containsKey(key)) {
                    til.error = "Plat sudah terdaftar"; return@setOnClickListener
                }
                til.error = null
                val nv = Vehicle(
                    plateKey = key,
                    plate = PlateParser.format(raw),
                    nama = f(R.id.etFNama).text.toString().trim(),
                    jenis = f(R.id.etFJenis).text.toString().trim(),
                    tipe = f(R.id.etFTipe).text.toString().trim(),
                    warna = f(R.id.etFWarna).text.toString().trim(),
                    keterangan = f(R.id.etFKet).text.toString().trim()
                )
                ioExec.execute {
                    if (editing != null && editing.plateKey != key) vDao.delete(editing)
                    vDao.upsertAll(listOf(nv))
                }
                dlg.dismiss()
                toast(if (editing == null) "Data ditambahkan" else "Data disimpan")
            }
        }
        dlg.show()
    }

    private fun importCsv(uri: Uri) {
        ioExec.execute {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                val (list, skipped) = CsvImport.toVehicles(CsvImport.parse(text))
                if (list.isEmpty()) {
                    runOnUiThread { toast("Tidak ada data plat yang terbaca. Cek kolom \"No plat\".") }
                    return@execute
                }
                val existing = vDao.keys().toHashSet()
                val added = list.count { it.plateKey !in existing }
                val updated = list.size - added
                vDao.upsertAll(list)
                Options.learn(applicationContext, list)
                runOnUiThread {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Impor selesai")
                        .setMessage("Baru: $added\nDiperbarui: $updated\nDilewati (plat kosong): $skipped")
                        .setPositiveButton("OK", null)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal impor: ${e.message}") }
            }
        }
    }

    /** Tampilkan riwayat sesuai sub riwayat yang dipilih. */
    private fun showLogs() {
        val shown = when (findViewById<ChipGroup>(R.id.groupLogFilter).checkedChipId) {
            R.id.chipLogFound -> logs.filter { !it.isTarget && !it.unregistered() }
            R.id.chipLogUnknown -> logs.filter { it.unregistered() }
            R.id.chipLogTarget -> logs.filter { it.isTarget }
            else -> logs
        }
        val q = PlateParser.key(findViewById<EditText>(R.id.etLogSearch).text.toString())
        val found = if (q.isEmpty()) shown else shown.filter { PlateParser.key(it.plate).contains(q) }
        val rows = LogRows.build(found)
        lAdapter.submitList(rows)
        tvLogCount.text = "${found.size} scan, ${rows.size} baris"
    }

    private fun autoDeleteDays() = getSharedPreferences("prefs", MODE_PRIVATE).getInt("auto_del_days", 0)

    /** Hanya riwayat tidak terdaftar; target dan terdaftar tidak disentuh. */
    private fun cleanOldUnknown() {
        val days = autoDeleteDays()
        if (days <= 0) return
        val before = System.currentTimeMillis() - days * 86_400_000L
        ioExec.execute { lDao.deleteOldUnknown(before) }
    }

    private fun setupLogTools() {
        findViewById<EditText>(R.id.etLogSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { showLogs() }
        })
        val btn = findViewById<MaterialButton>(R.id.btnAutoDelete)
        val values = intArrayOf(0, 7, 30)
        val labels = arrayOf("Mati", "Setelah 7 hari", "Setelah 30 hari")
        fun label() {
            btn.text = "Hapus otomatis tidak terdaftar: " + labels[values.indexOf(autoDeleteDays()).coerceAtLeast(0)]
        }
        label()
        btn.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Hapus otomatis (data lama langsung terhapus)")
                .setSingleChoiceItems(labels, values.indexOf(autoDeleteDays()).coerceAtLeast(0)) { d, which ->
                    getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("auto_del_days", values[which]).apply()
                    label()
                    cleanOldUnknown()
                    d.dismiss()
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        cleanOldUnknown()
    }

    private fun exportLog(uri: Uri) {
        val snapshot = logs
        ioExec.execute {
            try {
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
                contentResolver.openOutputStream(uri)!!.bufferedWriter().use { w ->
                    w.write("Waktu,No plat,Nama,Detail,Status\n")
                    for (l in snapshot) {
                        w.write(
                            listOf(fmt.format(Date(l.scannedAt)), l.plate, l.nama, l.detail,
                                if (l.isTarget) "Target" else if (l.unregistered()) "Tidak terdaftar" else "Terdaftar")
                                .joinToString(",") { q(it) } + "\n"
                        )
                    }
                }
                runOnUiThread { toast("Riwayat diekspor") }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal ekspor: ${e.message}") }
            }
        }
    }

    private fun confirm(msg: String, onYes: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setMessage(msg)
            .setPositiveButton("Hapus") { _, _ -> onYes() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        super.onDestroy()
        alertDialog?.dismiss()
        if (isFinishing) AlarmController.stop()
        camExec.shutdown(); ioExec.shutdown(); geoExec.shutdown(); recognizer.close()
    }
}
