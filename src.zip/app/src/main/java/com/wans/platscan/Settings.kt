package com.wans.platscan

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat

/** Pengaturan suara, getar, notifikasi, foto bukti & volume alarm. */
object AlarmSettings {
    private fun p(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun sound(c: Context) = p(c).getBoolean("al_sound", true)
    fun setSound(c: Context, v: Boolean) = p(c).edit().putBoolean("al_sound", v).apply()

    fun vibrate(c: Context) = p(c).getBoolean("al_vibrate", true)
    fun setVibrate(c: Context, v: Boolean) = p(c).edit().putBoolean("al_vibrate", v).apply()

    fun notif(c: Context) = p(c).getBoolean("al_notif", false)
    fun setNotif(c: Context, v: Boolean) = p(c).edit().putBoolean("al_notif", v).apply()

    fun volume(c: Context) = p(c).getInt("al_vol", 100)
    fun setVolume(c: Context, v: Int) = p(c).edit().putInt("al_vol", v).apply()

    /** Ambil foto bukti saat target ditemukan. */
    fun photo(c: Context) = p(c).getBoolean("al_photo", true)
    fun setPhoto(c: Context, v: Boolean) = p(c).edit().putBoolean("al_photo", v).apply()

    /** Scan beberapa plat sekaligus. */
    fun multi(c: Context) = p(c).getBoolean("scan_multi", false)
    fun setMulti(c: Context, v: Boolean) = p(c).edit().putBoolean("scan_multi", v).apply()

    fun hasNotifPermission(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

object Notifier {
    private const val CH = "target"
    private const val ID = 1001

    fun show(app: Context, log: ScanLog) {
        if (!AlarmSettings.notif(app) || !AlarmSettings.hasNotifPermission(app)) return
        val nm = app.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, "Target ditemukan", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            app, 0,
            Intent(app, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = listOf(log.plate, log.detail).filter { it.isNotBlank() }.joinToString(" \u00B7 ")
        val n = NotificationCompat.Builder(app, CH)
            .setSmallIcon(R.drawable.ic_tab_target)
            .setContentTitle("TARGET DITEMUKAN")
            .setContentText(text)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        try { nm.notify(ID, n) } catch (_: SecurityException) { }
    }

    fun cancel(c: Context?) {
        c?.getSystemService(NotificationManager::class.java)?.cancel(ID)
    }
}

/**
 * Pengaturan kotak penanda plat di layar Scan (bagian "KOTAK SCAN" di tab Setting).
 * Nilai di-cache di memori (@Volatile) supaya aman & murah dibaca dari onDraw / thread analisis,
 * dan langsung berlaku tanpa restart begitu setter dipanggil.
 */
object ScanBoxSettings {
    const val AUTO = "auto"
    const val MIN_DP = 1
    const val MAX_DP = 12
    const val DEF_DP = 3

    /** key, label, warna (urutan = urutan chip di Setting). */
    val colors: List<Triple<String, String, Int>> = listOf(
        Triple("white", "Putih", 0xFFFFFFFF.toInt()),
        Triple("green", "Hijau", 0xFF2EE66B.toInt()),
        Triple("blue", "Biru", 0xFF4DA3FF.toInt()),
        Triple("yellow", "Kuning", 0xFFFFD93D.toInt()),
        Triple("pink", "Pink", 0xFFFF7AD9.toInt()),
        Triple("red", "Merah", 0xFFFF3B4F.toInt())
    )

    @Volatile var show: Boolean = true
        private set
    @Volatile var widthDp: Int = DEF_DP
        private set
    @Volatile var colorKey: String = AUTO
        private set
    @Volatile var fixedColor: Int = colors[1].third
        private set

    val isAuto: Boolean get() = colorKey == AUTO

    private fun p(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    /** Panggil sekali di awal (MainActivity.onCreate). Aman dipanggil berulang. */
    fun load(c: Context) {
        val sp = p(c)
        show = sp.getBoolean("box_show", true)
        widthDp = sp.getInt("box_width", DEF_DP).coerceIn(MIN_DP, MAX_DP)
        applyColor(sp.getString("box_color", AUTO) ?: AUTO)
    }

    fun setShow(c: Context, v: Boolean) {
        show = v
        p(c).edit().putBoolean("box_show", v).apply()
    }

    fun setWidth(c: Context, dp: Int) {
        widthDp = dp.coerceIn(MIN_DP, MAX_DP)
        p(c).edit().putInt("box_width", widthDp).apply()
    }

    fun setColor(c: Context, key: String) {
        applyColor(key)
        p(c).edit().putString("box_color", colorKey).apply()
    }

    private fun applyColor(key: String) {
        val hit = colors.firstOrNull { it.first == key }
        if (hit == null) {
            colorKey = AUTO
        } else {
            colorKey = hit.first
            fixedColor = hit.third
        }
    }
}
