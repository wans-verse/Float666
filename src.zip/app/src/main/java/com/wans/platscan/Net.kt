package com.wans.platscan

import android.content.Context
import android.location.Geocoder
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.util.Locale

object Net {
    fun online(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}

object Geo {
    /** Blocking; panggil dari background thread. Null bila gagal. */
    @Suppress("DEPRECATION")
    fun lookup(c: Context, lat: Double, lon: Double): String? {
        return try {
            if (!Geocoder.isPresent()) return null
            val list = Geocoder(c, Locale("id", "ID")).getFromLocation(lat, lon, 1)
            val line = list?.firstOrNull()?.getAddressLine(0)
            if (line.isNullOrBlank()) null else line
        } catch (e: Exception) {
            null
        }
    }
}
