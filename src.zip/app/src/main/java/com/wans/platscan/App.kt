package com.wans.platscan

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AlarmController.init(this)
    }
}
