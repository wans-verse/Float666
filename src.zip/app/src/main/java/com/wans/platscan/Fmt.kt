package com.wans.platscan

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object Fmt {
    private val id = Locale("id", "ID")

    fun time(ms: Long): String =
        SimpleDateFormat("EEEE, dd MMM yyyy, HH:mm:ss", id).format(Date(ms))

    /** "budi santoso" / "BUDI SANTOSO" -> "Budi Santoso". */
    fun titleCase(s: String): String {
        val src = s.trim().replace(Regex("\\s+"), " ").lowercase(id)
        val sb = StringBuilder(src.length)
        var newWord = true
        for (ch in src) {
            if (ch.isLetter()) {
                sb.append(if (newWord) ch.titlecaseChar() else ch)
                newWord = false
            } else {
                sb.append(ch)
                newWord = !ch.isDigit()
            }
        }
        return sb.toString()
    }

    fun num(v: Double): String = String.format(Locale.US, "%.6f", v)

    fun coords(lat: Double, lon: Double): String = num(lat) + ", " + num(lon)

    fun mapsLink(lat: Double, lon: Double): String =
        "https://www.google.com/maps?q=" + num(lat) + "," + num(lon)

    fun accuracy(a: Float?): String = if (a == null) "" else "\u00B1" + a.roundToInt() + " m"

    /** Teks laporan untuk share sheet. */
    fun report(l: ScanLog): String {
        val sb = StringBuilder("TARGET DITEMUKAN\n")
        sb.append("Plat: ").append(l.plate).append('\n')
        Wilayah.of(l.plate)?.let { sb.append("Asal plat: ").append(it).append('\n') }
        sb.append("Jam: ").append(time(l.scannedAt)).append('\n')
        val nama = l.displayName()
        if (nama.isNotBlank()) sb.append("Nama: ").append(nama).append('\n')
        val kend = l.displayKendaraan()
        if (kend.isNotBlank()) sb.append("Kendaraan: ").append(kend).append('\n')
        if (l.warna.isNotBlank()) sb.append("Warna: ").append(l.warna).append('\n')
        val lat = l.lat
        val lon = l.lon
        if (lat != null && lon != null) {
            sb.append("Lokasi: ").append(coords(lat, lon))
            if (l.approx) sb.append(" (perkiraan)")
            sb.append('\n')
            if (!l.address.isNullOrBlank()) sb.append("Alamat: ").append(l.address).append('\n')
            sb.append("Peta: ").append(mapsLink(lat, lon))
        } else {
            sb.append("Lokasi: tidak tersedia")
        }
        return sb.toString()
    }
}

/** Log lama (sebelum v3) belum punya kolom terstruktur; pakai kolom lama sebagai cadangan. */
/** Penanda riwayat plat tidak terdaftar (disimpan di kolom catatan, tanpa ubah database). */
const val UNREGISTERED = "tidak_terdaftar"
fun ScanLog.unregistered(): Boolean = !isTarget && catatan == UNREGISTERED

fun ScanLog.legacy(): Boolean =
    ownerName.isBlank() && kendaraan.isBlank() && warna.isBlank() && catatan.isBlank()

fun ScanLog.displayName(): String = if (legacy()) nama else ownerName
fun ScanLog.displayKendaraan(): String = if (legacy()) detail else kendaraan

fun Context.shareReport(l: ScanLog) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Laporan target " + l.plate)
        putExtra(Intent.EXTRA_TEXT, Fmt.report(l))
    }
    startActivity(Intent.createChooser(i, "Bagikan laporan"))
}

fun Context.openMap(l: ScanLog) {
    val lat = l.lat ?: return
    val lon = l.lon ?: return
    val geo = Uri.parse("geo:" + Fmt.num(lat) + "," + Fmt.num(lon) +
        "?q=" + Fmt.num(lat) + "," + Fmt.num(lon) + "(" + Uri.encode(l.plate) + ")")
    try {
        startActivity(Intent(Intent.ACTION_VIEW, geo))
    } catch (e: ActivityNotFoundException) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Fmt.mapsLink(lat, lon))))
        } catch (e2: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi peta", Toast.LENGTH_LONG).show()
        }
    }
}
