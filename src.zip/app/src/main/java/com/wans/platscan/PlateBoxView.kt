package com.wans.platscan

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.camera.view.PreviewView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Kotak penanda plat di atas PreviewView.
 *
 * - [track] menerima kotak plat dalam koordinat gambar analisis (sudah tegak / sudah diputar sesuai
 *   rotationDegrees) lalu mengonversinya ke koordinat view sesuai scaleType PreviewView.
 * - Kotak berpindah halus (~120 ms) dan memudar bila tidak ada update ~600 ms.
 * - Tidak menangkap sentuhan. Tidak ada alokasi di onDraw / listener animasi.
 * - [previewMode] = true dipakai di kartu Setting: menggambar plat contoh + kotak yang
 *   langsung berubah saat pengaturan diubah.
 */
class PlateBoxView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val FOUND = 0
        const val NOT_FOUND = 1
        const val TARGET = 2
        const val WARN = 3

        private const val MOVE_MS = 120L
        private const val FADE_IN_MS = 140L
        private const val FADE_OUT_MS = 220L
        private const val HIDE_AFTER_MS = 600L
        private const val DEMO_STEP_MS = 1500L

        private const val PAD_DP = 6f
        private const val CORNER_DP = 14f

        private const val C_FOUND = 0xFF2EE66B.toInt()
        private const val C_NOT_FOUND = 0xFFFF3B4F.toInt()
        private const val C_TARGET = 0xFFFF1744.toInt()
        private const val C_WARN = 0xFFFFC247.toInt()
    }

    /** Harus sama dengan scaleType PreviewView (default PreviewView = FILL_CENTER). */
    var scaleType: PreviewView.ScaleType = PreviewView.ScaleType.FILL_CENTER

    /** Mode pratinjau untuk kartu Setting. */
    var previewMode: Boolean = false
        set(v) {
            field = v
            if (isAttachedToWindow) { if (v && isShown) startDemo() else stopDemo() }
            updatePulse()
            invalidate()
        }

    private val dp = resources.displayMetrics.density

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val platePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF111111.toInt()
    }
    private val plateEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * dp
        color = 0x80FFFFFF.toInt()
    }
    private val plateText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val fm = Paint.FontMetrics()
    private val path = Path()

    // Posisi kotak (koordinat view)
    private val cur = RectF()
    private val from = RectF()
    private val to = RectF()
    private val tmp = RectF()

    private var shown = false
    private var status = NOT_FOUND
    private var pulse = 0f

    // Pratinjau
    private val demoPlate = RectF()
    private val demoBox = RectF()
    private var demoBaseline = 0f
    private var demoStatus = FOUND

    private val move = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = MOVE_MS
        interpolator = DecelerateInterpolator()
        addUpdateListener {
            val f = it.animatedFraction
            cur.left = from.left + (to.left - from.left) * f
            cur.top = from.top + (to.top - from.top) * f
            cur.right = from.right + (to.right - from.right) * f
            cur.bottom = from.bottom + (to.bottom - from.bottom) * f
            invalidate()
        }
    }

    private var fadeFrom = 0f
    private var fadeTarget = 1f
    private val fade = ValueAnimator.ofFloat(0f, 1f).apply {
        addUpdateListener {
            val f = it.animatedFraction
            alpha = fadeFrom + (fadeTarget - fadeFrom) * f
            if (f >= 1f && fadeTarget == 0f && shown) {
                shown = false
                updatePulse()
            }
        }
    }

    private val pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 520L
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener {
            pulse = it.animatedFraction
            invalidate()
        }
    }

    private val hideRun = Runnable { startFade(0f, FADE_OUT_MS) }
    private val demoRun = object : Runnable {
        override fun run() {
            if (ScanBoxSettings.isAuto) {
                demoStatus = (demoStatus + 1) % 4
                updatePulse()
                invalidate()
            }
            postDelayed(this, DEMO_STEP_MS)
        }
    }

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = false

    override fun hasOverlappingRendering(): Boolean = false

    // ---------- API ----------

    /**
     * @param l,t,r,b kotak plat dalam koordinat gambar analisis yang sudah tegak
     *        (output ML Kit setelah rotationDegrees diterapkan).
     * @param srcW,srcH ukuran gambar tegak itu (lebar/tinggi sudah ditukar bila rotasi 90/270).
     */
    fun track(l: Int, t: Int, r: Int, b: Int, srcW: Int, srcH: Int, st: Int) {
        if (previewMode || !ScanBoxSettings.show) return
        if (width == 0 || height == 0 || srcW <= 0 || srcH <= 0) return

        val vw = width.toFloat()
        val vh = height.toFloat()
        val fillMode = when (scaleType) {
            PreviewView.ScaleType.FILL_START,
            PreviewView.ScaleType.FILL_CENTER,
            PreviewView.ScaleType.FILL_END -> true
            else -> false
        }
        val sx = vw / srcW
        val sy = vh / srcH
        val s = if (fillMode) max(sx, sy) else min(sx, sy)
        val align = when (scaleType) {
            PreviewView.ScaleType.FILL_START, PreviewView.ScaleType.FIT_START -> 0f
            PreviewView.ScaleType.FILL_END, PreviewView.ScaleType.FIT_END -> 1f
            else -> 0.5f
        }
        val ox = (vw - srcW * s) * align
        val oy = (vh - srcH * s) * align
        val pad = PAD_DP * dp

        tmp.set(l * s + ox - pad, t * s + oy - pad, r * s + ox + pad, b * s + oy + pad)
        // Di luar area yang terlihat (terpotong FILL): abaikan.
        if (tmp.right <= 0f || tmp.bottom <= 0f || tmp.left >= vw || tmp.top >= vh) return
        tmp.left = max(tmp.left, 0f); tmp.top = max(tmp.top, 0f)
        tmp.right = min(tmp.right, vw); tmp.bottom = min(tmp.bottom, vh)

        status = st
        updatePulse()
        removeCallbacks(hideRun)
        postDelayed(hideRun, HIDE_AFTER_MS)

        if (!shown) {
            shown = true
            cur.set(tmp); from.set(tmp); to.set(tmp)
            move.cancel()
            alpha = 0f
            startFade(1f, FADE_IN_MS)
            updatePulse()
        } else {
            if (fadeTarget == 0f && fade.isRunning) startFade(1f, FADE_IN_MS)
            val eps = 1.5f * dp
            val same = abs(tmp.left - to.left) < eps && abs(tmp.top - to.top) < eps &&
                abs(tmp.right - to.right) < eps && abs(tmp.bottom - to.bottom) < eps
            if (!same) {
                from.set(cur)
                to.set(tmp)
                move.cancel()
                move.start()
            }
        }
        invalidate()
    }

    /** Dipanggil saat pengaturan berubah (tampil/sembunyi, tebal, warna). */
    fun refresh() {
        if (previewMode) {
            alpha = if (ScanBoxSettings.show) 1f else 0.35f
        } else if (!ScanBoxSettings.show) {
            removeCallbacks(hideRun)
            fade.cancel(); move.cancel()
            shown = false
            alpha = 0f
        }
        updatePulse()
        invalidate()
    }

    // ---------- Animasi ----------

    private fun startFade(target: Float, ms: Long) {
        fade.cancel()
        fadeFrom = alpha
        fadeTarget = target
        fade.duration = ms
        fade.start()
    }

    private fun updatePulse() {
        val st = if (previewMode) demoStatus else status
        val visible = isAttachedToWindow && isShown && ScanBoxSettings.show &&
            (previewMode || shown)
        val need = visible && ScanBoxSettings.isAuto && st == TARGET
        if (need) {
            if (!pulseAnim.isRunning) pulseAnim.start()
        } else if (pulseAnim.isRunning) {
            pulseAnim.cancel()
            pulse = 0f
        }
    }

    private fun startDemo() {
        removeCallbacks(demoRun)
        postDelayed(demoRun, DEMO_STEP_MS)
    }

    private fun stopDemo() {
        removeCallbacks(demoRun)
    }

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (previewMode) {
            if (isVisible) startDemo() else stopDemo()
        }
        updatePulse()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (previewMode && isShown) startDemo()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(hideRun)
        removeCallbacks(demoRun)
        move.cancel(); fade.cancel(); pulseAnim.cancel()
        pulse = 0f
        if (!previewMode) { shown = false; alpha = 0f }
        super.onDetachedFromWindow()
    }

    // ---------- Gambar ----------

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Geometri pratinjau: plat contoh di tengah.
        val plateH = min(h * 0.34f, w * 0.5f / 3.2f)
        val plateW = plateH * 3.2f
        val cx = w / 2f
        val cy = h / 2f
        demoPlate.set(cx - plateW / 2f, cy - plateH / 2f, cx + plateW / 2f, cy + plateH / 2f)
        val pad = PAD_DP * dp
        demoBox.set(
            demoPlate.left - pad, demoPlate.top - pad,
            demoPlate.right + pad, demoPlate.bottom + pad
        )
        plateText.textSize = plateH * 0.58f
        plateText.getFontMetrics(fm)
        demoBaseline = cy - (fm.ascent + fm.descent) / 2f
    }

    override fun onDraw(canvas: Canvas) {
        if (previewMode) {
            val rr = demoPlate.height() * 0.18f
            canvas.drawRoundRect(demoPlate, rr, rr, platePaint)
            canvas.drawRoundRect(demoPlate, rr, rr, plateEdge)
            canvas.drawText("AB 1234 CD", demoPlate.centerX(), demoBaseline, plateText)
            drawBox(canvas, demoBox, demoStatus)
            return
        }
        if (!shown || !ScanBoxSettings.show) return
        drawBox(canvas, cur, status)
    }

    private fun drawBox(c: Canvas, r: RectF, st: Int) {
        val w = r.width()
        val h = r.height()
        if (w < 2f || h < 2f) return

        val auto = ScanBoxSettings.isAuto
        val color = if (auto) statusColor(st) else ScanBoxSettings.fixedColor
        val sw = ScanBoxSettings.widthDp * dp
        val rad = min(CORNER_DP * dp, min(w, h) / 3f)

        // Isi tipis supaya plat terlihat "terpilih"
        fill.color = color
        fill.alpha = 26
        c.drawRoundRect(r, rad, rad, fill)

        // Nyala untuk target (hanya mode otomatis)
        if (auto && st == TARGET) {
            glow.color = color
            glow.strokeWidth = sw * 2.8f
            glow.alpha = (50 + 100 * pulse).toInt()
            c.drawRoundRect(r, rad, rad, glow)
        }

        // Bracket di empat pojok (garis tetap di dalam kotak)
        val half = sw / 2f
        val l = r.left + half
        val t = r.top + half
        val rt = r.right - half
        val b = r.bottom - half
        val rr = max(1f, min(rad, min(rt - l, b - t) / 2f))
        val len = min(max(min(w, h) * 0.32f, rr + sw), min(rt - l, b - t) / 2f)

        path.rewind()
        path.moveTo(l, t + len); path.lineTo(l, t + rr); path.quadTo(l, t, l + rr, t); path.lineTo(l + len, t)
        path.moveTo(rt - len, t); path.lineTo(rt - rr, t); path.quadTo(rt, t, rt, t + rr); path.lineTo(rt, t + len)
        path.moveTo(rt, b - len); path.lineTo(rt, b - rr); path.quadTo(rt, b, rt - rr, b); path.lineTo(rt - len, b)
        path.moveTo(l + len, b); path.lineTo(l + rr, b); path.quadTo(l, b, l, b - rr); path.lineTo(l, b - len)

        stroke.color = color
        stroke.strokeWidth = sw
        c.drawPath(path, stroke)
    }

    private fun statusColor(st: Int): Int = when (st) {
        FOUND -> C_FOUND
        TARGET -> C_TARGET
        WARN -> C_WARN
        else -> C_NOT_FOUND
    }
}
