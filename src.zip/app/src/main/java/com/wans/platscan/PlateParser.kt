package com.wans.platscan

import android.graphics.Rect
import com.google.mlkit.vision.text.Text

/** Format plat Indonesia: 1-2 huruf (wilayah) + 1-4 angka + 1-3 huruf. Contoh: AB 1234 CD */
object PlateParser {
    private val rx = Regex("^([A-Z]{1,2})(\\d{1,4})([A-Z]{1,3})$")

    /** Bentuk standar untuk pencocokan: huruf besar, tanpa spasi/simbol. */
    fun key(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    /** Bentuk tampilan: "AB 1234 CD" bila polanya cocok, selain itu apa adanya. */
    fun format(s: String): String {
        val m = rx.matchEntire(key(s)) ?: return s.trim().uppercase()
        return "${m.groupValues[1]} ${m.groupValues[2]} ${m.groupValues[3]}"
    }

    /** Cari plat valid dari teks hasil OCR. */
    fun find(raw: String): String? {
        val lines = raw.uppercase().split('\n')
        for (c in lines + lines.joinToString("")) {
            val m = rx.matchEntire(key(c)) ?: continue
            if (Wilayah.of(m.groupValues[1]) == null) continue // huruf depan tidak dikenal = salah baca
            return "${m.groupValues[1]} ${m.groupValues[2]} ${m.groupValues[3]}"
        }
        return null
    }

    /** Semua plat berbeda dalam satu frame. Plat 2 baris hanya digabung dalam blok teks yang sama. */
    fun findAll(text: Text): List<String> {
        val out = LinkedHashSet<String>()
        for (b in text.textBlocks) {
            var i = 0
            while (i < b.lines.size) {
                val one = find(b.lines[i].text)
                if (one != null) { out.add(one); i++; continue }
                val next = b.lines.getOrNull(i + 1)
                val two = if (next == null || find(next.text) != null) null
                    else find(key(b.lines[i].text) + key(next.text))
                if (two != null) { out.add(two); i += 2 } else i++
            }
        }
        if (out.isEmpty()) find(text.text)?.let { out.add(it) }
        return out.toList()
    }

    /**
     * Cari kotak (koordinat gambar tegak dari ML Kit) untuk plat dengan [plateKey] hasil [find].
     * Dicoba: satu TextLine utuh, lalu beberapa TextLine berurutan (plat 2 baris, mis. motor).
     * Hasil ditulis ke [out]; false bila tidak ketemu.
     */
    fun findBox(text: Text, plateKey: String, out: Rect): Boolean {
        val lines = ArrayList<Text.Line>()
        for (b in text.textBlocks) lines.addAll(b.lines)

        for (ln in lines) {
            val bb = ln.boundingBox ?: continue
            if (key(ln.text) == plateKey) { out.set(bb); return true }
        }
        for (i in lines.indices) {
            val sb = StringBuilder()
            var have = false
            for (j in i until minOf(i + 3, lines.size)) {
                val bb = lines[j].boundingBox ?: break
                sb.append(key(lines[j].text))
                if (!have) { out.set(bb); have = true } else out.union(bb)
                if (sb.length >= plateKey.length) {
                    if (sb.toString() == plateKey) return true
                    break
                }
            }
        }
        return false
    }

    /** Key di database yang beda tepat satu karakter (kemungkinan salah baca OCR). */
    fun similar(key: String, keys: Collection<String>): String? =
        keys.firstOrNull { k ->
            k.length == key.length && k.indices.count { k[it] != key[it] } == 1
        }
}
