package com.wans.platscan

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/** Tampilan penuh foto bukti. */
class PhotoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo)
        val name = intent.getStringExtra(EXTRA_FILE)
        val iv = findViewById<ImageView>(R.id.photoView)
        findViewById<android.view.View>(R.id.btnClosePhoto).setOnClickListener { finish() }
        iv.setOnClickListener { finish() }

        if (name == null) { finish(); return }
        val app = applicationContext
        Executors.newSingleThreadExecutor().execute {
            val f = Evidence.file(app, name)
            val bmp: Bitmap? = if (f.exists()) Evidence.decodeSampled(f, 1600) else null
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (bmp == null) {
                    Toast.makeText(this, "Foto tidak ditemukan", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    iv.setImageBitmap(bmp)
                }
            }
        }
    }

    companion object {
        const val EXTRA_FILE = "photo_file"
    }
}
